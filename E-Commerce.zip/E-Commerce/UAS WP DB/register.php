<?php
require 'backend_apotek/konekDB.php';
if(isset($_POST["submit"]) ) {

            $nama_lengkap = $_POST["name"];
            $username = $_POST["username"];
            $email = $_POST["email"];
            $password = $_POST["password"];
            $confirmPassword = $_POST["confirm-password"];

            //jadikan username yang udh ada di database tidak boleh sama 
            $konek = mysqli_query($conn, "SELECT username FROM login WHERE username = '$username'");
            if(mysqli_fetch_assoc($konek)) {
                echo "<script> 
                        alert('username sudah digunakan');
                        window.location='register.php';
                    </script>";
                return false;
            }

            //password harus sama dengan konfirmasi password
            if($password !== $confirmPassword){
                echo "<script> 
                        alert ('password tidak sama');
                        window.location='register.php';
                    </script>";
                return false;
            }

            $password2 = $password;

            $sambung = "INSERT INTO login VALUES ('', '$nama_lengkap', '$username', '$email', '$password2')";
            $hubung = mysqli_query($conn, $sambung);
            if($hubung > 0) {
                echo "<script>
                        alert('registrasi berhasil');
                        window.location='login.php';
                    </script>";
                }else{
                echo "<script>
                        alert('registrasi gagall');
                        window.location='register.php';
                    </script>";

            }
        }
?>

<!DOCTYPE html>
<html>
<head>
    <title>Registrasi</title>
    <style>
        /* Gaya CSS untuk tata letak dan tampilan form */
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-size: contain;
            background-repeat: no-repeat;
            background-position: center; 
            background-image: url('ICONS/obat2.jpg');
            background-size: 100% auto;
        }
        .container {
            max-width: 400px;
            margin: 100px auto;
            padding: 20px;
            text-align:center;
            border-radius:30px;
            background-color: rgba(255, 255, 255, 0.8);
            color:white;
            
        }
        
        h2 {
            text-align: center;
            color: black;
        }
        
        .form-group {
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            margin-left:80px;
            color: black;
        }
        
        .form-group label {
            display: block;
        }
        
        .form-group input[type="text"],
        .form-group input[type="email"],
        .form-group input[type="password"] {
            width: 70%;
            padding: 10px;
            border-radius:10px;
            text-align:center;
        }
        
        .form-button {
            text-align: center;
        }
        
        .form-button button {
            padding: 10px 20px;
            background-color: black;
            color: #fff;
            border: none;
            cursor: pointer;
            text-decoration:none;
        }
        
        .form-button button:hover {
            background-color:grey;
        }
        
        .login-text {
            text-align: center;
            margin-top: 20px;
            color: black;
        }

        .login-link {
            color: #4CAF50;
            text-decoration: none;
            font-weight: bold;
        }

        .login-link:hover {
        color: black;
        }
      
    </style>
</head>

<body background="bg1.jpg">
    <div class="container">
        <h2>REGISTRATION FORM</h2>
        <form method="POST" action="">
            <div class="form-group">
                <input type="text" id="name" name="name" placeholder="Nama Lengkap" required>
            </div>
            <div class="form-group">
                <input type="text" id="username" name="username" placeholder="Username" required>
            </div>
            <div class="form-group">
                <input type="email" id="email" name="email"placeholder="Email" required>
            </div>
            <div class="form-group">
                <input type="password" id="password" name="password" placeholder="Password" required>
            </div>
            <div class="form-group">
                <input type="password" id="confirm-password" name="confirm-password" placeholder="Confirm Password" required>
            </div>
           
            <div class="form-button">
                <button type="submit" id="btn-register" name="submit">Register </button>
            </div>
        </form>
        <div class="login-text">
            Sudah punya akun? <a class="login-link" href="login.php">Login </a> sekarang
        </div>
    </div>
</body>
</html>
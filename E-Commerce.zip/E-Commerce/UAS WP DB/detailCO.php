<?php
session_start();

if(!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit;
}

$username = $_SESSION['username'];

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles.css">
    <title>Checkout Details</title>
    <style>

body {
    font-family: Arial, sans-serif;
    background-color: #f4f4f4;
    margin: 0;
    padding: 0;
}

.checkout-form {
    max-width: 400px;
    margin: 50px auto;
    background: rgb(208,239,219);
    background: radial-gradient(circle, rgba(208,239,219,1) 16%, rgba(80,220,228,1) 79%);
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

h2 {
    text-align: center;
    color: #333;
}

form {
    display: grid;
    gap: 10px;
}

label {
    font-size: 16px;
    color: #555;
}

input,
select,
textarea {
    width: 100%;
    padding: 8px;
    box-sizing: border-box;
    border: 1px solid #ddd;
    border-radius: 4px;
    margin-top: 4px;
}

input[type="submit"] {
    background-color: black;
    color: #fff;
    cursor: pointer;
    font-size: 16px;
    padding: 10px;
    border: none;
    border-radius: 4px;
}

input[type="submit"]:hover {
    background-color: #45a049;
}

    </style>
</head>
<body>
<!-- DETAILS CO -->

<h2>SELAMAT DATANG <br><?php echo $username; ?></h2>

    <div class="checkout-form">
        <h2>Checkout Details</h2>
        <form action="backend_apotek/proses_Checkout.php" method="post">
            <label for="fname">Nama Pertama:</label>
            <input type="text" id="fname" name="nama_pertama" required>

            <label for="lname">Nama Terakhir:</label>
            <input type="text" id="lname" name="nama_terakhir" required>

            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required>

            <label for="address">Alamat:</label>
            <textarea id="address" name="alamat" required></textarea>

            <label for="city">Kota:</label>
            <input type="text" id="city" name="kota" required>

            <label for="zip">Kode Pos:</label>
            <input type="text" id="zip" name="kode_pos" required>

            <label for="country">Negara:</label>
            <select id="country" name="negara" required>
                <option value="usa">United States</option>
                <option value="Indonesia">Indonesia</option>
                <option value="uk">English</option>
                <option value="uk">Malaysia</option>
                <!-- Tambahkan opsi negara lainnya sesuai kebutuhan -->
            </select>
            <input type="submit" value="Submit">
        </form>
        <a href="backend_apotek/hapusSession_login.php">kembali</a> <!-- UNTUK MENGHAPUS SESSION -->
    </div>
    <!-- END DETAILS -->
</body>
</html>

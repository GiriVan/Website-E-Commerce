<?php
require 'konekDB.php';

$nama_pertama = $_POST["nama_pertama"];
$nama_terakhir = $_POST["nama_terakhir"];
$email = $_POST["email"];
$alamat = $_POST["alamat"];
$kota = $_POST["kota"];
$kode_pos = $_POST["kode_pos"];
$negara = $_POST["negara"];

$query = "INSERT INTO checkout VALUES ('', '$nama_pertama', '$nama_terakhir', '$email', '$alamat', '$kota', '$kode_pos', '$negara')";

$cek = mysqli_query($conn, $query);

if ($cek) {
    echo "<script> alert('Selamat Checkout Berhasil'); 
          document.location.href = 'hasil_checkout.php';
         </script>";
} else {
    echo "<script> alert('Checkout Gagall');
        document.location.href = '../detailCO.php';
        </script>";
}
?>


<?php
    session_start();
    
    if(!isset($_SESSION['username'])) {
        header("Location: login.php");
        exit;
    }
    
    require 'konekDB.php';
    
    $sambung = query("SELECT * FROM checkout");

    
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout</title>
    <style>
        body {
            margin: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-color: #ffffff; /* Warna putih */
        }

        .checkout-container {
            padding: 20px;
            border-radius: 10px;
            text-align: center;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1); /* Bayangan lembut */
        }

        .green-background {
            background-color: #2ecc71; /* Warna hijau untuk latar belakang teks */
            color: #ffffff; /* Warna teks putih */
            padding: 10px;
            border-radius: 5px;
        }

        .location-icon {
            font-size: 24px;
            color: #2ecc71; /* Warna hijau untuk ikon lokasi */
        }

        h2 {
            color: #333; /* Warna teks hitam */
        }
    </style>
</head>
<body>
    <div class="checkout-container">
        <div class="green-background">
            <span class="location-icon">&#127760;</span> <!-- Ikon lokasi -->
            <h2>SELAMAT CHECKOUT ANDA BERHASIL</h2>
        </div>
        
        <!-- PRODUK 13 -->
                        <table border="2" cellpadding=30 cellspacing=0>

                         
                                <tr>
                                                  
                                    <th><span class="las la-sort"></span> Nama Pertama</th>
                                    <th><span class="las la-sort"></span> Nama Terakhir</th>
                                    <th><span class="las la-sort"></span> Email</th>
                                    <th><span class="las la-sort"></span> Alamat</th>
                                    <th><span class="las la-sort"></span> Kota</th>
                                    <th><span class="las la-sort"></span> Kode Pos</th>
                                    <th><span class="las la-sort"></span> Negara</th>
                                    <th><span class="las la-sort"></span> Pemesanan</th>
                                </tr>

                               
                                <?php foreach($sambung as $bung) : ?>
                                <tr>
                                    
                                    <td><?= $bung["nama_pertama"]?></td>
                                    <td><?= $bung["nama_terakhir"]?></td>
                                    <td><?= $bung["email"]?></td>
                                    <td><?= $bung["alamat"]?></td>
                                    <td><?= $bung["kota"]?></td>
                                    <td><?= $bung["kode_pos"]?></td>
                                    <td><?= $bung["negara"]?></td>
                                    <td>
                                        <a href="detail_produk.php">Detail</a>
                                    </td>
                                    
                                    
                                    <?php endforeach ?>
                                    </tr>
                            
                        </table>
                        <button type="button" class="btn btn-secondary" onclick="window.location.href='hapusSession_login.php'">Logout</button>
<!-- END -->
        
    </div>
</body>
</html>

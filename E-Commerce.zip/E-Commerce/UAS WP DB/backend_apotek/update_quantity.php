<?php
require 'konekDB.php';

if (!$conn) {
    echo "Gagal terhubung";
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["productId"]) && isset($_POST["newQuantity"])) {
    $productId = $_POST["productId"];
    $newQuantity = $_POST["newQuantity"];

    // Perbarui jumlah di database
    $updateQuery = "UPDATE `semua_produk` SET quantity = $newQuantity WHERE id = $productId";
    mysqli_query($conn, $updateQuery);

    // Hitung dan kembalikan harga total baru
    $totalQuery = "SELECT quantity * price AS total FROM `semua_produk` WHERE id = $productId";
    $result = mysqli_query($conn, $totalQuery);
    $row = mysqli_fetch_assoc($result);
    echo number_format($row["total"], 3);
} else {
    echo "Permintaan tidak valid";
}
?>

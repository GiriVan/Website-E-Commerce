<?php

require 'backend_apotek/konekDB.php';

if(!$conn){
    echo "Failed to Connect";
}

if(isset($_GET["action"]) && $_GET["action"] == "delete"){
    $productName = $_GET["name"];
    $deleteQuery = "DELETE FROM `semua_produk` WHERE description = '$productName'";
    mysqli_query($conn, $deleteQuery);
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CART</title>

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

    <!-- Bootsratp -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">


    <link rel="stylesheet" href="style.css">
</head>
<body>
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320">
        <path fill="#313236" fill-opacity="1" d="M0,256L48,218.7C96,181,192,107,288,106.7C384,107,480,181,576,176C672,171,768,85,864,90.7C960,96,1056,192,1152,218.7C1248,245,1344,203,1392,181.3L1440,160L1440,0L1392,0C1344,0,1248,0,1152,0C1056,0,960,0,864,0C768,0,672,0,576,0C480,0,384,0,288,0C192,0,96,0,48,0L0,0Z">
        </path>
    </svg>

    <div class="container">
        <h2 class='text-center text-blask'>Pesanan Anda</h2>
        <button type="button" class="btn btn-dark" onclick="window.location.href='index1.php'">Kembali</button>
        <table class="table"> <br><br><br>
            <thead class="table-dark">
            <tr>
                <th></th>
                <th>Nama produk</th>
                <th>Harga produk</th>
                <th>Satuan</th>
                <th>Total harga</th>
                <th>Hapus produk</th>
            </tr>
        </thead>

            <tbody>
                
                </thead>

                <?php
$query = "SELECT * FROM `semua_produk` ORDER BY id ASC";
$result = mysqli_query($conn, $query);
$total = 0; // Variabel untuk menyimpan total harga

if (mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_array($result)) {
        // Di dalam loop while di mana produk ditampilkan
        ?>
        <tbody>
            <!-- Di dalam loop while di mana produk ditampilkan -->
            <tr>
                <td><img style="width: 150px;" src="ICONS/<?php echo $row["image"];?>" alt=""></td>
                <td><?php echo $row["description"];?></td>
                <td><?php echo $row["price"];?></td>
                <td>
                    <input type="number" min="1" name="quantity" value="<?php echo $row["quantity"];?>" data-product-id="<?php echo $row["id"];?>" class="quantity-input">
                </td>
                <td id="total_<?php echo $row["id"];?>"><?php echo number_format($row["quantity"] * $row["price"], 3 );?></td>
                <td><a href="cart.php?action=delete&name=<?php echo $row["description"];?>"><button type="button" class="btn btn-danger" >Hapus Produk</button></a></td>
            </tr>

        </tbody>

        <?php
        // Hitung total harga untuk produk saat ini
        $subTotal = $row["quantity"] * $row["price"];

        // Update total harga di variabel $total
        $total += $subTotal;

        // Perbarui nilai quantity dan total harga di database
        // $updateQuery = "INSERT INTO semua_produk` SET 
        // quantity = '{$row['quantity']}', 
        // price = '$subTotal' 
        // WHERE id = '{$row['id']}'";

        // mysqli_query($conn, $updateQuery);
    }
}
?>

    </tr>

    <tbody>
        <tr></tr>
        <tr>
            <td></td>
            <td></td>
            <td></td>
            <td>Total</td>
            <td>Rp.<?php echo number_format($total, 3);?></td>
            <td><button type="button" class="btn btn-success" onclick="window.location.href='login.php'">Checkout</button></td>
        </tr>
    </tbody>
</table>


        <div class="text-right" id="checkout">
            <!-- <button type="button" class="btn btn-outline-secondary" >Update Cart</button> -->
            <!-- <a href="" id="updateCartLink" class="btn btn-outline-secondary">Update Cart</a> -->

            
            <!-- <button type="button" class="btn btn-secondary" onclick="window.location.href='backend_apotek/update_cart.php'">Update</button> -->
        </div>
    </div>

    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320">
        <path fill="#313236" fill-opacity="1" d="M0,256L48,234.7C96,213,192,171,288,176C384,181,480,235,576,224C672,213,768,139,864,133.3C960,128,1056,192,1152,218.7C1248,245,1344,235,1392,229.3L1440,224L1440,320L1392,320C1344,320,1248,320,1152,320C1056,320,960,320,864,320C768,320,672,320,576,320C480,320,384,320,288,320C192,320,96,320,48,320L0,320Z">
        </path>
    </svg>





<!-- Setelah memuat jQuery -->
<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>

<script>
$(document).ready(function(){
    // Event listener untuk perubahan pada input jumlah
    $('.quantity-input').on('change', function(){
        var productId = $(this).data('product-id');
        var newQuantity = $(this).val();

        // Kirim jumlah baru ke server menggunakan AJAX
        $.ajax({
            type: 'POST',
            url: 'backend_apotek/update_quantity.php',
            data: {productId: productId, newQuantity: newQuantity},
            success: function(response){
                // Update harga total di tabel
                $('#total_' + productId).text(response);
            },
            error: function(){
                console.log('Error updating quantity');
            }
        });
    });
});
</script>

</body>
</html>

<?php
require '../DB/konekDB.php';
            $id = $_GET["id"];
            $username = $_POST["username"];
            $password = $_POST["password"];
            $konfirmasiPassword = $_POST["konfirmasiPassword"];

            //jadikan username yang udh ada di database tidak boleh sama 
            $konek = mysqli_query($conn, "SELECT username FROM tb_login WHERE username = '$username'");
            if(mysqli_fetch_assoc($konek)) {
                echo "<script> 
                        alert('username sudah pernah digunakan');
                    </script>";
                return false;
            }

            //password harus sama dengan konfirmasi password
            if($password !== $konfirmasiPassword){
                echo "<script> 
                        alert ('password tidak sama');
                        window.location.href='lupaPassword.php';
                    </script>";
                return false;
            }

            $password2 = md5($password);

            $sambung = "UPDATE tb_login SET
            username = '$username',
            password = '$password2'
            WHERE id = $id
            ";
            $hubung = mysqli_query($conn, $sambung);
            if($hubung) {
                echo "<script>
                        alert('Nama dan Password berhasil diganti');
                        window.location.href='login.php';
                    </script>";
                }else{
                echo "<script>
                        alert('Nama dan Password gagal diganti');
                        window.location.href='lupaPassword.php';
                    </script>";

            }
            
        
?>
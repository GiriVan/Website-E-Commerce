<?php
    $conn = mysqli_connect("localhost", "root", "", "apotek");



    function query($apotek){ //FUNCTION UNTUK MENAMPILKAN DATABASE
        global $conn;
        $konek = mysqli_query($conn, $apotek);
        $rows = [];
        while ($row = mysqli_fetch_assoc($konek)) {
            $rows[] = $row;
        };
        return $rows;
    }

















?>
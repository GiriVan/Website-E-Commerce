<?php
    require '../DB/konekDB.php';

    $nama_obat = $_POST["nama_obat"];
    $penyimpanan = $_POST["penyimpanan"];
    $kategori = $_POST["kategori"];
    $stok = $_POST["stok"];
    $kadaluwarsa = $_POST["kadaluwarsa"];
    $harga = $_POST["harga"];
    $unit = $_POST["unit"];

    $query = "INSERT INTO tb_obat (nama_obat, penyimpanan, kategori, stok, kadaluwarsa, harga, unit) 
              VALUES ('$nama_obat', '$penyimpanan', '$kategori', '$stok', '$kadaluwarsa', '$harga', '$unit')";

    $cek = mysqli_query($conn, $query);

    if ($cek) {
        echo "<script> alert('Data berhasil ditambahkan'); 
              document.location.href = '../obat.php';
             </script>";
    } else {
        echo "<script> alert('Data gagal ditambahkan');
            document.location.href = '../obat.php';
            </script>";
    }
?>

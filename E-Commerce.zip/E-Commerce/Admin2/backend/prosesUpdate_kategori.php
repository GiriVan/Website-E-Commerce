<?php
require '../DB/konekDB.php';

$id = $_GET['id'];
$nama_kategori = mysqli_real_escape_string($conn, $_POST['nama_kategori']); //mysqli_real_escape_string = sebuah array security biar tidak bisa nulis kodingan html di formnya
$deskripsi = mysqli_real_escape_string($conn, $_POST['deskripsi']);

$query = "UPDATE tb_kategori SET 
           nama_kategori='$nama_kategori',
           deskripsi='$deskripsi'
           WHERE id='$id'";
$eksekusi = mysqli_query($conn, $query);
if ($eksekusi){
    echo "<script> 
            alert('Data Berhasil di Update!');
            window.location.href='../kategori.php';
            </script>";
        }
        else{
            echo "<script> 
            alert('Data Gagal di Update!');
            window.location.href='../update_kategori.php';
           
    </script>";
}
?>
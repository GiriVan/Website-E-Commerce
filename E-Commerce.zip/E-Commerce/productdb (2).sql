-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 01 Mar 2024 pada 07.30
-- Versi server: 10.4.28-MariaDB
-- Versi PHP: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `productdb`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `checkout`
--
-- Kesalahan membaca struktur untuk tabel productdb.checkout: #1932 - Table &#039;productdb.checkout&#039; doesn&#039;t exist in engine
-- Kesalahan membaca data untuk tabel productdb.checkout: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `productdb`.`checkout`&#039; at line 1

-- --------------------------------------------------------

--
-- Struktur dari tabel `data_transaksi`
--
-- Kesalahan membaca struktur untuk tabel productdb.data_transaksi: #1932 - Table &#039;productdb.data_transaksi&#039; doesn&#039;t exist in engine
-- Kesalahan membaca data untuk tabel productdb.data_transaksi: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `productdb`.`data_transaksi`&#039; at line 1

-- --------------------------------------------------------

--
-- Struktur dari tabel `login`
--
-- Kesalahan membaca struktur untuk tabel productdb.login: #1932 - Table &#039;productdb.login&#039; doesn&#039;t exist in engine
-- Kesalahan membaca data untuk tabel productdb.login: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `productdb`.`login`&#039; at line 1

-- --------------------------------------------------------

--
-- Struktur dari tabel `semua_produk`
--
-- Kesalahan membaca struktur untuk tabel productdb.semua_produk: #1932 - Table &#039;productdb.semua_produk&#039; doesn&#039;t exist in engine
-- Kesalahan membaca data untuk tabel productdb.semua_produk: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `productdb`.`semua_produk`&#039; at line 1

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_alendronate`
--

CREATE TABLE `tb_alendronate` (
  `id` int(11) NOT NULL,
  `description` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `price` double(10,3) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data untuk tabel `tb_alendronate`
--

INSERT INTO `tb_alendronate` (`id`, `description`, `image`, `price`) VALUES
(1, 'Alendronate - Alovell 10 Mg 10 Tablet', '16 - Alendronate.png', 149.200);

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_combatrin`
--
-- Kesalahan membaca struktur untuk tabel productdb.tb_combatrin: #1932 - Table &#039;productdb.tb_combatrin&#039; doesn&#039;t exist in engine
-- Kesalahan membaca data untuk tabel productdb.tb_combatrin: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `productdb`.`tb_combatrin`&#039; at line 1

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_combivent`
--
-- Kesalahan membaca struktur untuk tabel productdb.tb_combivent: #1932 - Table &#039;productdb.tb_combivent&#039; doesn&#039;t exist in engine
-- Kesalahan membaca data untuk tabel productdb.tb_combivent: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `productdb`.`tb_combivent`&#039; at line 1

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_counterpain`
--
-- Kesalahan membaca struktur untuk tabel productdb.tb_counterpain: #1932 - Table &#039;productdb.tb_counterpain&#039; doesn&#039;t exist in engine
-- Kesalahan membaca data untuk tabel productdb.tb_counterpain: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `productdb`.`tb_counterpain`&#039; at line 1

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_degirol`
--
-- Kesalahan membaca struktur untuk tabel productdb.tb_degirol: #1932 - Table &#039;productdb.tb_degirol&#039; doesn&#039;t exist in engine
-- Kesalahan membaca data untuk tabel productdb.tb_degirol: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `productdb`.`tb_degirol`&#039; at line 1

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_enlapril`
--
-- Kesalahan membaca struktur untuk tabel productdb.tb_enlapril: #1932 - Table &#039;productdb.tb_enlapril&#039; doesn&#039;t exist in engine
-- Kesalahan membaca data untuk tabel productdb.tb_enlapril: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `productdb`.`tb_enlapril`&#039; at line 1

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_enzyplex`
--
-- Kesalahan membaca struktur untuk tabel productdb.tb_enzyplex: #1932 - Table &#039;productdb.tb_enzyplex&#039; doesn&#039;t exist in engine
-- Kesalahan membaca data untuk tabel productdb.tb_enzyplex: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `productdb`.`tb_enzyplex`&#039; at line 1

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_fluticasone`
--
-- Kesalahan membaca struktur untuk tabel productdb.tb_fluticasone: #1932 - Table &#039;productdb.tb_fluticasone&#039; doesn&#039;t exist in engine
-- Kesalahan membaca data untuk tabel productdb.tb_fluticasone: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `productdb`.`tb_fluticasone`&#039; at line 1

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_insto`
--
-- Kesalahan membaca struktur untuk tabel productdb.tb_insto: #1932 - Table &#039;productdb.tb_insto&#039; doesn&#039;t exist in engine
-- Kesalahan membaca data untuk tabel productdb.tb_insto: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `productdb`.`tb_insto`&#039; at line 1

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_komix`
--
-- Kesalahan membaca struktur untuk tabel productdb.tb_komix: #1932 - Table &#039;productdb.tb_komix&#039; doesn&#039;t exist in engine
-- Kesalahan membaca data untuk tabel productdb.tb_komix: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `productdb`.`tb_komix`&#039; at line 1

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_loperamide`
--
-- Kesalahan membaca struktur untuk tabel productdb.tb_loperamide: #1932 - Table &#039;productdb.tb_loperamide&#039; doesn&#039;t exist in engine
-- Kesalahan membaca data untuk tabel productdb.tb_loperamide: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `productdb`.`tb_loperamide`&#039; at line 1

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_loratadine`
--
-- Kesalahan membaca struktur untuk tabel productdb.tb_loratadine: #1932 - Table &#039;productdb.tb_loratadine&#039; doesn&#039;t exist in engine
-- Kesalahan membaca data untuk tabel productdb.tb_loratadine: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `productdb`.`tb_loratadine`&#039; at line 1

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_miconazole`
--
-- Kesalahan membaca struktur untuk tabel productdb.tb_miconazole: #1932 - Table &#039;productdb.tb_miconazole&#039; doesn&#039;t exist in engine
-- Kesalahan membaca data untuk tabel productdb.tb_miconazole: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `productdb`.`tb_miconazole`&#039; at line 1

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_nebilet`
--
-- Kesalahan membaca struktur untuk tabel productdb.tb_nebilet: #1932 - Table &#039;productdb.tb_nebilet&#039; doesn&#039;t exist in engine
-- Kesalahan membaca data untuk tabel productdb.tb_nebilet: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `productdb`.`tb_nebilet`&#039; at line 1

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_paracetamol`
--
-- Kesalahan membaca struktur untuk tabel productdb.tb_paracetamol: #1932 - Table &#039;productdb.tb_paracetamol&#039; doesn&#039;t exist in engine
-- Kesalahan membaca data untuk tabel productdb.tb_paracetamol: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `productdb`.`tb_paracetamol`&#039; at line 1

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `tb_alendronate`
--
ALTER TABLE `tb_alendronate`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `tb_alendronate`
--
ALTER TABLE `tb_alendronate`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Apotek Kami</title>

    <!-- FONT AWESOME CDN LINK -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">

    <!-- SWIPER UNTUK BISA NGE SLIDER-->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css">

    <!-- HUBUNGKAN KE CSS -->
    <link rel="stylesheet" href="css/style2.css">

    <style>
   

    </style>

</head>
<body>

    <!-- header -->
    <header>
        
        <a href="#" class="logo"><i class="fa fa-hospital"></i>Apotek.</a>

        <nav class="navbar">
            <a class="" href="#home">Home</a>
            <a href="#about">About</a>
            <a href="#obat">Product</a>
            <a href="#review">Review</a>           
        </nav>

        <div class="icons">
            <i class="fas fa-bars" id="menu-bars"></i>
            <i class="fas fa-search" id="search-icon"></i>
            <a href="#" class="fas fa-heart"></a>
            <a href="#" class="fas fa-shopping-cart"></a>
        </div>

    </header>
<!-- END HEADER -->

<!-- UNTUK MEMBUAT TAMPILAN SEARCH -->
<form action="" id="search-form">
    <input type="search" placeholder="carii disniii" name="" id="sercing">
    <label for="sercing" class="fas fa-search"></label>
    <i class="fas fa-times" id="close"></i>
</form>
<!-- END SEARCH -->

    <div class="container">
        <div class="product-details">
            <div class="product-image">
                <img src="../ICONS/18 - Fluticasone.png" alt="Gambar Produk">
            </div>
            <div class="product-info">
                <h1>Fluticasone - Avamys Nasal Spray</h1>
                <span>Rp192.400 - Rp297.300/botol</span>
                <a href="../index1.php?#obat" class="btn">Pembelian</a>
                <div class="product-details-section">
                    <h2>Deskripsi</h2>
                    <p>AVAMYS NASAL SPRAY digunakan untuk pengobatan rhinitis alergi, yaitu suatu kondisi pembengkakan membran nasal di dalam hidung yang ditandai dengan bersin-bersin, hidung gatal, hidung tersumbat dan hidung meler yang dipicu oleh adanya alergen (sesuatu yang dapat menimbulkan reaksi alergi). Avamys nasal mengandung flutikason furoat termasuk ke dalam golongan kortikosteroid, yaitu golongan obat bersifat sebagai antiinflamasi dengan mencegah dikeluarkannya mediator inflamasi oleh tubuh. Dalam penggunaan obat ini harus SESUAI DENGAN PETUNJUK DOKTER. Pembelian obat ini memerlukan edukasi terkait penggunaan atau pengonsumsian obat yang tepat dan aman yang akan dikenakan biaya.</p>
                    <h2>Indikasi Umum</h2>
                    <p>INFORMASI OBAT INI HANYA UNTUK KALANGAN MEDIS. Rhinorrhea, hidung tersumbat/gatal, & alergi rinitis.</p>
                    <h2>komposisi</h2>
                    <p>Tiap spray/semprot : Fluticasone furoate 27.5 mcg</p>
                    <h2>Dosis</h2>
                    <p>PENGGUNAAN OBAT INI HARUS SESUAI DENGAN PETUNJUK DOKTER. Dewasa dan remaja =12 th dosis awal 2 sprays sekali sehari. dosis pemeliharaan: 1 spray sekali sehari. anak 2-11 th 1 spray sekali sehari, dosis pemeliharaan: 1 spray sekali sehari.</p>
                    <h2>Aturan Pakai :</h2>
                    <p>kocok perlahan terlebih dahulu lalu semprotkan pada lubang hidung. Tutup lubang hidung yang sebelah kiri jika lubang hidung sebelah kanan akan disemprot, begitu juga sebaliknya. Setelah di semprot hirup dalam-dalam.</p>
                    <h2>Perhatian</h2>
                    <p>HARUS DENGAN RESEP DOKTER. glaukoma, asma akut, imunosupresi.</p>
                    <h2>Kontra Indikasi</h2>
                    <p>gangguan hati, tuberkulosis, operasi nasa, glaukoma, Ibu Hamil dan menyusui,katarak.</p>
                    <h2>Efek Samping</h2>
                    <p>Pemakaian obat umumnya memiliki efek samping tertentu dan sesuai dengan masing-masing individu. Jika terjadi efek samping yang berlebih dan berbahaya, harap konsultasikan kepada tenaga medis. Efek samping yang mungkin terjadi dalam penggunaan obat adalah: Luka pada hidung.</p>
                    <h2>Golongan Produk</h2>
                    <p>Obat Keras (Merah)</p>
                    <h2>Kemasan</h2>
                    <p>Dus, Botol @ 120 Spray</p>
                    <h2>Manufaktur</h2>
                    <p>GlaxoSmithKline Indonesia</p>
                    <h2>No. Registrasi</h2>
                    <p>BPOM: DKI0975704356A1`</p>
                </div>
                
            </div>
        </div>
    </div>
</body>
</html>

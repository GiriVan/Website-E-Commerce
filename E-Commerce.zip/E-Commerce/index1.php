<?php

require 'backend_apotek/konekDB.php';

if(!$conn){
    echo "Failed to Connect";
}

if(isset($_POST["add"])){
    $producId = $_GET["id"];
    $productName = $_POST["hidden_name"];
    $productImage = $_POST["hidden_image"];
    $productPrice = $_POST["hidden_price"];
    $productQuantity = $_POST["quantity"];

    $sql = "INSERT INTO `semua_produk` (`description`, `image`, `price`, `quantity`) VALUES ('$productName', '$productImage', '$productPrice', '$productQuantity');";
    $konek = mysqli_query($conn, $sql);
    if ($konek > 0) {
        echo "<script> 
                alert('Sudah masuk kedalam keranjang');
                
                </script>";
            }else{
                echo "<script> 
                alert('gagal masuk kedalam keranjang');
                
                
            </script>";
        }
}

$query1 = $conn->query("SELECT * FROM semua_produk");

$jml_produk = mysqli_num_rows($query1);


?>

<!DOCTYPE html>
<html lang="en">
<head>
    
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Apotek Kami</title>

    <!-- FONT AWESOME CDN LINK -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">

    <!-- SWIPER UNTUK BISA NGE SLIDER-->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css">

    <!-- HUBUNGKAN KE CSS -->
    <link rel="stylesheet" href="css/style.css">

    <!-- UNTUK BAGIAN FOOTER -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    

    <!-- CSS TEKS BERJALAN  -->
<style>
    .berjalan {
    padding: 20px;
    overflow: hidden;
    font-family: 'Belanosima', sans-serif;
    font-size: 15px;
    margin-top:50px;            
    text-align: center;
    font-weight: bold;
 }
 
 .berjalan p {
    animation: marquee 25s linear infinite;
    height: 10px;
 }
 
 
 @keyframes marquee {
 0% { transform: translateX(100%); }
 100% { transform: translateX(-100%); }
 }

 .product p {
     font-size: 15px;
    }

    .icons {
    position: relative;
}

.cart-notification {
    position: absolute;
    top: -10px; /* Sesuaikan dengan posisi yang diinginkan di atas ikon cart */
    right: -10px; /* Sesuaikan dengan posisi yang diinginkan di atas ikon cart */
    background-color: red;
    color: white;
    font-size: 12px;
    padding: 4px 8px;
    border-radius: 50%;
}

/* UNTUK MEMBUAT TAMPILAN CARTNYA JADI KYA NOTIFIKASI GITU */
.icons {
    position: relative;
}

.cart-notification {
    position: absolute;
    top: -10px; /* Sesuaikan dengan posisi yang diinginkan di atas ikon cart */
    right: -10px; /* Sesuaikan dengan posisi yang diinginkan di atas ikon cart */
    background-color: red;
    color: white;
    font-size: 12px;
    width: 20px; /* Sesuaikan dengan ukuran yang diinginkan */
    height: 30px; /* Sesuaikan dengan ukuran yang diinginkan */
    line-height: 20px; /* Sesuaikan dengan ukuran yang diinginkan */
    text-align: center;
    border-radius: 50%;
}

/* PENUTUP NOTIFIKASI CART */



</style>
</head>

<body>

    <!-- header -->
    <header>
        
    <a href="#" class="logo">
    <i><img src="ICONS/hospital.png" alt="" style="width: 45px; height: 40px;"></i>MyApotek

        <nav class="navbar">
            <a class="home" href="#home">Home</a>
            <a href="#about">About</a>
            <a href="#obat">Product</a>
            <a href="#review">Review</a>           
        </nav>

        <div class="icons">
             <a href="login.php" class="fas fa-user" id="user-icon"></a>
            <i class="fas fa-bars" id="menu-bars"></i>
            <i class="fas fa-search" id="search-icon"></i>
            <a href="#" class="fas fa-heart"></a>
            <!-- <a href="cart.php" class="fas fa-shopping-cart"></a>   -->
            <a href="cart.php" class="fa fa-shopping-cart">
                <span class="cart-notification"><?= number_format($jml_produk, 0, ",", "."); ?></span>
            </a>
        </div>
       
    </header>

<!-- TEKS BERJALAN -->
<div class="berjalan">
        <p>Selamat datang di MyApotek Kami hadir untuk memenuhi kebutuhan kesehatan Anda. Terima kasih atas kepercayaan Anda, dan mari bersama-sama menjaga kesehatan  </p>
</div>
<!-- END TEKS BERJALAN -->

<!-- END HEADER -->


<!-- UNTUK MEMBUAT TAMPILAN SEARCH -->
<form action="" id="search-form">
    <input type="search" placeholder="carii disni" name="" id="sercing">
    <label for="sercing" class="fas fa-search"></label>
    <i class="fas fa-times" id="close"></i>
</form>
<!-- END SEARCH -->


<!--  HOME SECTION  -->

<section class="home" id="home">

    <div class="swiper mySwiper home-slider"> <!-- class swiper ini untuk bisa nge slide konten gambarnya -->
        <div class="swiper-wrapper wrapper">

            <div class="swiper-slide slide">
                <div class="content">
                    <span>Toko obat terpercaya</span>
                    <h3>Kami Siap Melayani</h3>
                    <p>Segera beli obat di apotek kami</p>
                    <a href="about" class="btn">MyApotek</a>
                </div>
                <div class="image">
                    <img src="ICONS/dispensary1.png" alt="foto obat">
                </div>
            </div>
            <div class="swiper-slide slide">
                <div class="content">
                    <span>Toko obat terpercaya</span>
                <h3>Kesehatan No.1</h3>
                    <p>Segera beli obat di apotek kami</p>
                    <a href="#about" class="btn">MyApotek</a>
                </div>
                <div class="image">
                    <img src="ICONS/pharmacy.png" alt="foto obat">
                </div>
            </div>
            <div class="swiper-slide slide">
                <div class="content">
                    <span>Toko obat terpercaya</span>
                <h3>Sembuh Bersama!! </h3>
                    <p>Segera beli obat di apotek kami</p>
                    <a href="#about" class="btn">MyApotek</a>
                </div>
                <div class="image">
                    <img src="ICONS/10.png" alt="foto obat">
                </div>
            </div>
            <div class="swiper-slide slide">
                <div class="content">
                    <span>Toko obat terpercaya</span>
                <h3>Kemudahan dan Keamanan</h3>
                    <p>Segera beli obat di apotek kami</p>
                    <a href="#about" class="btn">MyApotek</a>
                </div>
                <div class="image">
                    <img src="ICONS/pills.png" alt="foto obat">
                </div>
            </div>

        </div>

        <div class="swiper-pagination"></div>

    </div>

</section>

<!-- END HOME SECTION -->


<!-- About halaman -->

    <section class="about" id="about">
        
        <h3 class="sub-heading">Tentang Kami</h3>
        <h1 class="heading"> kenapa pilih kami? </h1>

    <div class="row">

        <div class="image">
            <img src="ICONS/10.png" alt="">
        </div>

        <div class="content">
        <h3 style="text-align: center;">Apotek Kami</h3>
            <p>Selamat datang di Toko Apotek, destinasi terpercaya untuk semua kebutuhan kesehatan Anda. Kami di Toko Apotek berkomitmen untuk menyediakan produk dan layanan kesehatan berkualitas tinggi kepada pelanggan kami. 
            Dengan beragam produk farmasi, obat-obatan, suplemen kesehatan, dan vitamin, kami hadir untuk memenuhi kebutuhan kesehatan Anda. Tim profesional kami siap memberikan bantuan dan konsultasi obat untuk memastikan 
            Anda mendapatkan informasi yang akurat.</p>
            <p>Nikmati kenyamanan berbelanja dengan layanan cepat dan ramah di Toko Apotek. Daftarkan diri Anda untuk menerima penawaran khusus dan pembaruan terbaru tentang produk dan layanan kami. Kunjungilah Toko
            Apotek hari ini dan percayakan kesehatan Anda pada kami. Terima kasih telah memilih Toko Apotek sebagai mitra kesehatan Anda.</p>
            <div class="icons-container">
                <div class="icons">
                    <i class="fas fa-shipping-fast"></i>
                    <span>Gratis Ongkir</span>
                </div>
                <div class="icons">
                    <i class="fas fa-dollar-sign"></i>
                    <span>Diskonn</span>
                </div>
                <div class="icons">
                    <i class="fas fa-headset"></i>
                    <span>Pay Later</span>
                </div>
            </div>
        </div>

    </div>

    </section>
    
    <div class="container3">
        <div class="box1">
            <div class="image1" >
            <img src="ICONS/iyep.jpg">
        </div>
            <div class="caption1">
                <p>Ariefa Diah Mayangsari</p>
                <p>17213014</p>
                <p>Backend</p>
            </div>
        </div>
        <div class="box1">
            <div class="image1">
            <img src="ICONS/giri.jpeg">
            </div>
            <div class="caption1">
                <p>Giri Van Transco</p>
                <p>17213029</p>
                <p>Backend</p>
            </div>
        </div>
        <div class="box1">
            <div class="image1">
            <img src="ICONS/billa.jpeg">
            </div>
            <div class="caption1">
                <p>Nabilla Putri Sahara</p>
                <p>17211018</p>
                <p>Frontend</p>
            </div>
        </div>
        <div class="box1">
            <div class="image1">
            <img src="ICONS/pina.jpeg">
            </div>
            <div class="caption1">
                <p>Vina Agustina</p>
                <p>17211013</p>
                <p>Frontend</p>
            </div>
        </div>
    </div>

<!-- END About halaman -->



<!-- PENJUALAN OBATNYA -->

<section class="obat" id="obat">
    <h3 class="sub-heading"> Tersedia Obat </h3>
    <h1 class="heading"> Dijamin Sembuh </h1>

    <div class="box-container">
<!-- PRODUK 1 -->
    <?php
        $query = "SELECT * FROM `tb_alendronate` ORDER BY id ASC";
        $result = mysqli_query($conn, $query);

        if (mysqli_num_rows($result) > 0) {
            while ($row = mysqli_fetch_array($result)) {
                ?>
                <div class="box product">
                    <form action="index1.php?action=add&id=<?= $row["id"];?>" method="POST">
                        <a href="#" class="fas fa-heart"></a>
                        <a href="produk/alendronate.php" class="fas fa-eye"></a>
                        <img src="ICONS/<?php echo $row["image"]; ?>" alt="">
                        <h3><?php echo $row["description"]; ?></h3>
                        <p>Rp.<?php echo $row["price"]; ?>/satuan</p>
                        <p>★★★★☆ (4.7/5)</p>
                        <p>4RB + Terjual</p>
                        <p>KOTA BANDUNG</p>
                        <input type="hidden" id="quantity" name="quantity" value="1"><br>
                        <input type="hidden" name="hidden_image" value="<?php echo $row["image"]; ?>">
                        <input type="hidden" name="hidden_name" value="<?php echo $row["description"]; ?>">
                        <input type="hidden" name="hidden_price" value="<?php echo $row["price"]; ?>">
                        <input type="submit" name="add" value="Add to Cart" class="btn">
                    </form>
                    
                </div>
                <?php
            }
        }
        ?>
<!-- END  -->

<!-- PRODUK 2 -->
    <?php
        $query = "SELECT * FROM `tb_loperamide` ORDER BY id ASC";
        $result = mysqli_query($conn, $query);

        if (mysqli_num_rows($result) > 0) {
            while ($row = mysqli_fetch_array($result)) {
                ?>
                <div class="box product">
                    <form action="index1.php?action=add&id=<?= $row["id"];?>" method="POST">
                        <a href="#" class="fas fa-heart"></a>
                        <a href="produk/loperamide.php" class="fas fa-eye"></a>
                        <img src="ICONS/<?php echo $row["image"]; ?>" alt="">
                        <h3><?php echo $row["description"]; ?></h3>
                        <p>Rp.<?php echo $row["price"]; ?>/strip</p>
                        <p>★★★★☆ (4.7/5)</p>
                        <p>4RB + Terjual</p>
                        <p>KOTA BANDUNG</p>
                        <input type="hidden" id="quantity" name="quantity" value="1"><br>
                        <input type="hidden" name="hidden_image" value="<?php echo $row["image"]; ?>">
                        <input type="hidden" name="hidden_name" value="<?php echo $row["description"]; ?>">
                        <input type="hidden" name="hidden_price" value="<?php echo $row["price"]; ?>">
                        <input type="submit" name="add" value="Add to Cart" class="btn">
                    </form>
                    
                </div>
                <?php
            }
        }
        ?>
<!-- END -->

<!-- PRODUK 3 -->
    <?php
        $query = "SELECT * FROM `tb_insto` ORDER BY id ASC";
        $result = mysqli_query($conn, $query);

        if (mysqli_num_rows($result) > 0) {
            while ($row = mysqli_fetch_array($result)) {
                ?>
                <div class="box product">
                    <form action="index1.php?action=add&id=<?= $row["id"];?>" method="POST">
                        <a href="#" class="fas fa-heart"></a>
                        <a href="produk/insto.php" class="fas fa-eye"></a>
                        <img src="ICONS/<?php echo $row["image"]; ?>" alt="">
                        <h3><?php echo $row["description"]; ?></h3>
                        <p>Rp.<?php echo $row["price"]; ?>/botol</p>
                        <p>★★★★☆ (4.9/5)</p>
                        <p>13RB + Terjual</p>
                        <p>KOTA BANDUNG</p>
                        <input type="hidden" id="quantity" name="quantity" value="1"><br>
                        <input type="hidden" name="hidden_image" value="<?php echo $row["image"]; ?>">
                        <input type="hidden" name="hidden_name" value="<?php echo $row["description"]; ?>">
                        <input type="hidden" name="hidden_price" value="<?php echo $row["price"]; ?>">
                        <input type="submit" name="add" value="Add to Cart" class="btn">
                    </form>
                    
                </div>
                <?php
            }
        }
        ?>
<!-- END -->

<!-- PRODUK 4 -->
    <?php
        $query = "SELECT * FROM `tb_komix` ORDER BY id ASC";
        $result = mysqli_query($conn, $query);

        if (mysqli_num_rows($result) > 0) {
            while ($row = mysqli_fetch_array($result)) {
                ?>
                <div class="box product">
                    <form action="index1.php?action=add&id=<?= $row["id"];?>" method="POST">
                        <a href="#" class="fas fa-heart"></a>
                        <a href="produk/komix.php" class="fas fa-eye"></a>
                        <img src="ICONS/<?php echo $row["image"]; ?>" alt="">
                        <h3><?php echo $row["description"]; ?></h3>
                        <p>Rp.<?php echo $row["price"]; ?>/box</p>
                        <p>★★★☆☆ (4.5/5)</p>
                        <p>8.5RB + Terjual</p>
                        <p>KOTA BANDUNG</p>
                        <input type="hidden" id="quantity" name="quantity" value="1"><br>
                        <input type="hidden" name="hidden_image" value="<?php echo $row["image"]; ?>">
                        <input type="hidden" name="hidden_name" value="<?php echo $row["description"]; ?>">
                        <input type="hidden" name="hidden_price" value="<?php echo $row["price"]; ?>">
                        <input type="submit" name="add" value="Add to Cart" class="btn">
                    </form>
                    
                </div>
                <?php
            }
        }
        ?>
<!-- END -->

<!-- PRODUK 5 -->
    <?php
        $query = "SELECT * FROM `tb_enzyplex` ORDER BY id ASC";
        $result = mysqli_query($conn, $query);

        if (mysqli_num_rows($result) > 0) {
            while ($row = mysqli_fetch_array($result)) {
                ?>
                <div class="box product">
                    <form action="index1.php?action=add&id=<?= $row["id"];?>" method="POST">
                        <a href="#" class="fas fa-heart"></a>
                        <a href="produk/enzyplex.php" class="fas fa-eye"></a>
                        <img src="ICONS/<?php echo $row["image"]; ?>" alt="">
                        <h3><?php echo $row["description"]; ?></h3>
                        <p>Rp.<?php echo $row["price"]; ?>/Strip</p>
                        <p>★★★★☆ (4.3/5)</p>
                        <p>7.5RB + Terjual</p>
                        <p>KOTA BANDUNG</p>
                        <input type="hidden" id="quantity" name="quantity" value="1"><br>
                        <input type="hidden" name="hidden_image" value="<?php echo $row["image"]; ?>">
                        <input type="hidden" name="hidden_name" value="<?php echo $row["description"]; ?>">
                        <input type="hidden" name="hidden_price" value="<?php echo $row["price"]; ?>">
                        <input type="submit" name="add" value="Add to Cart" class="btn">
                    </form>
                    
                </div>
                <?php
            }
        }
        ?>
<!-- END -->

<!-- PRODUK 6 -->
    <?php
        $query = "SELECT * FROM `tb_paracetamol` ORDER BY id ASC";
        $result = mysqli_query($conn, $query);

        if (mysqli_num_rows($result) > 0) {
            while ($row = mysqli_fetch_array($result)) {
                ?>
                <div class="box product">
                    <form action="index1.php?action=add&id=<?= $row["id"];?>" method="POST">
                        <a href="#" class="fas fa-heart"></a>
                        <a href="produk/paracetamol.php" class="fas fa-eye"></a>
                        <img src="ICONS/<?php echo $row["image"]; ?>" alt="">
                        <h3><?php echo $row["description"]; ?></h3>
                        <p>Rp.<?php echo $row["price"]; ?>/Strip</p>
                        <p>★★★★☆ (4.6/3)</p>
                        <p>19RB + Terjual</p>
                        <p>KOTA BANDUNG</p>
                        <input type="hidden" id="quantity" name="quantity" value="1"><br>
                        <input type="hidden" name="hidden_image" value="<?php echo $row["image"]; ?>">
                        <input type="hidden" name="hidden_name" value="<?php echo $row["description"]; ?>">
                        <input type="hidden" name="hidden_price" value="<?php echo $row["price"]; ?>">
                        <input type="submit" name="add" value="Add to Cart" class="btn">
                    </form>
                    
                </div>
                <?php
            }
        }
        ?>
<!-- END -->

<!-- PRODUK 7 -->
    <?php
        $query = "SELECT * FROM `tb_combatrin` ORDER BY id ASC";
        $result = mysqli_query($conn, $query);

        if (mysqli_num_rows($result) > 0) {
            while ($row = mysqli_fetch_array($result)) {
                ?>
                <div class="box product">
                    <form action="index1.php?action=add&id=<?= $row["id"];?>" method="POST">
                        <a href="#" class="fas fa-heart"></a>
                        <a href="produk/combatrin.php" class="fas fa-eye"></a>
                        <img src="ICONS/<?php echo $row["image"]; ?>" alt="">
                        <h3><?php echo $row["description"]; ?></h3>
                        <p>Rp.<?php echo $row["price"]; ?>/Botol</p>
                        <p>★★★★☆ (5/5)</p>
                        <p>8RB + Terjual</p>
                        <p>KOTA BANDUNG</p>
                        <input type="hidden" id="quantity" name="quantity" value="1"><br>
                        <input type="hidden" name="hidden_image" value="<?php echo $row["image"]; ?>">
                        <input type="hidden" name="hidden_name" value="<?php echo $row["description"]; ?>">
                        <input type="hidden" name="hidden_price" value="<?php echo $row["price"]; ?>">
                        <input type="submit" name="add" value="Add to Cart" class="btn">
                    </form>
                    
                </div>
                <?php
            }
        }
        ?>
<!-- END -->

<!-- PRODUK 8 -->
    <?php
        $query = "SELECT * FROM `tb_combivent` ORDER BY id ASC";
        $result = mysqli_query($conn, $query);

        if (mysqli_num_rows($result) > 0) {
            while ($row = mysqli_fetch_array($result)) {
                ?>
                <div class="box product">
                    <form action="index1.php?action=add&id=<?= $row["id"];?>" method="POST">
                        <a href="#" class="fas fa-heart"></a>
                        <a href="produk/combivent.php" class="fas fa-eye"></a>
                        <img src="ICONS/<?php echo $row["image"]; ?>" alt="">
                        <h3><?php echo $row["description"]; ?></h3>
                        <p>Rp.<?php echo $row["price"]; ?>/Strip</p>
                        <p>★★★★☆ (9/5)</p>
                        <p>16RB + Terjual</p>
                        <p>KOTA BANDUNG</p>
                        <input type="hidden" id="quantity" name="quantity" value="1"><br>
                        <input type="hidden" name="hidden_image" value="<?php echo $row["image"]; ?>">
                        <input type="hidden" name="hidden_name" value="<?php echo $row["description"]; ?>">
                        <input type="hidden" name="hidden_price" value="<?php echo $row["price"]; ?>">
                        <input type="submit" name="add" value="Add to Cart" class="btn">
                    </form>
                    
                </div>
                <?php
            }
        }
        ?>
<!-- END -->

<!-- PRODUK 8 -->
    <?php
        $query = "SELECT * FROM `tb_loratadine` ORDER BY id ASC";
        $result = mysqli_query($conn, $query);

        if (mysqli_num_rows($result) > 0) {
            while ($row = mysqli_fetch_array($result)) {
                ?>
                <div class="box product">
                    <form action="index1.php?action=add&id=<?= $row["id"];?>" method="POST">
                        <a href="#" class="fas fa-heart"></a>
                        <a href="produk/loratadine.php" class="fas fa-eye"></a>
                        <img src="ICONS/<?php echo $row["image"]; ?>" alt="">
                        <h3><?php echo $row["description"]; ?></h3>
                        <p>Rp.<?php echo $row["price"]; ?>/Tablet</p>
                        <p>★★★★☆ (8.9/9)</p>
                        <p>12RB + Terjual</p>
                        <p>KOTA BANDUNG</p>
                        <input type="hidden" id="quantity" name="quantity" value="1"><br>
                        <input type="hidden" name="hidden_image" value="<?php echo $row["image"]; ?>">
                        <input type="hidden" name="hidden_name" value="<?php echo $row["description"]; ?>">
                        <input type="hidden" name="hidden_price" value="<?php echo $row["price"]; ?>">
                        <input type="submit" name="add" value="Add to Cart" class="btn">
                    </form>
                    
                </div>
                <?php
            }
        }
        ?>
<!-- END -->

<!-- PRODUK 9 -->
    <?php
        $query = "SELECT * FROM `tb_nebilet` ORDER BY id ASC";
        $result = mysqli_query($conn, $query);

        if (mysqli_num_rows($result) > 0) {
            while ($row = mysqli_fetch_array($result)) {
                ?>
                <div class="box product">
                    <form action="index1.php?action=add&id=<?= $row["id"];?>" method="POST">
                        <a href="#" class="fas fa-heart"></a>
                        <a href="produk/nebilet.php" class="fas fa-eye"></a>
                        <img src="ICONS/<?php echo $row["image"]; ?>" alt="">
                        <h3><?php echo $row["description"]; ?></h3>
                        <p>Rp.<?php echo $row["price"]; ?>/Tablet</p>
                        <p>★★★★☆ (7.8/5)</p>
                        <p>7RB + Terjual</p>
                        <p>KOTA BANDUNG</p>
                        <input type="hidden" id="quantity" name="quantity" value="1"><br>
                        <input type="hidden" name="hidden_image" value="<?php echo $row["image"]; ?>">
                        <input type="hidden" name="hidden_name" value="<?php echo $row["description"]; ?>">
                        <input type="hidden" name="hidden_price" value="<?php echo $row["price"]; ?>">
                        <input type="submit" name="add" value="Add to Cart" class="btn">
                    </form>
                    
                </div>
                <?php
            }
        }
        ?>
<!-- END -->

<!-- PRODUK 10 -->
    <?php
        $query = "SELECT * FROM `tb_enlapril` ORDER BY id ASC";
        $result = mysqli_query($conn, $query);

        if (mysqli_num_rows($result) > 0) {
            while ($row = mysqli_fetch_array($result)) {
                ?>
                <div class="box product">
                    <form action="index1.php?action=add&id=<?= $row["id"];?>" method="POST">
                        <a href="#" class="fas fa-heart"></a>
                        <a href="produk/enlapril.php" class="fas fa-eye"></a>
                        <img src="ICONS/<?php echo $row["image"]; ?>" alt="">
                        <h3><?php echo $row["description"]; ?></h3>
                        <p>Rp.<?php echo $row["price"]; ?>/Kaplet</p>
                        <p>★★★★☆ (8/5)</p>
                        <p>4RB + Terjual</p>
                        <p>KOTA BANDUNG</p>
                        <input type="hidden" id="quantity" name="quantity" value="1"><br>
                        <input type="hidden" name="hidden_image" value="<?php echo $row["image"]; ?>">
                        <input type="hidden" name="hidden_name" value="<?php echo $row["description"]; ?>">
                        <input type="hidden" name="hidden_price" value="<?php echo $row["price"]; ?>">
                        <input type="submit" name="add" value="Add to Cart" class="btn">
                    </form>
                    
                </div>
                <?php
            }
        }
        ?>
<!-- END -->

<!-- PRODUK 11 -->
    <?php
        $query = "SELECT * FROM `tb_fluticasone` ORDER BY id ASC";
        $result = mysqli_query($conn, $query);

        if (mysqli_num_rows($result) > 0) {
            while ($row = mysqli_fetch_array($result)) {
                ?>
                <div class="box product">
                    <form action="index1.php?action=add&id=<?= $row["id"];?>" method="POST">
                        <a href="#" class="fas fa-heart"></a>
                        <a href="produk/fluticasone.php" class="fas fa-eye"></a>
                        <img src="ICONS/<?php echo $row["image"]; ?>" alt="">
                        <h3><?php echo $row["description"]; ?></h3>
                        <p>Rp.<?php echo $row["price"]; ?>/Kaplet</p>
                        <p>★★★★☆ (6/5)</p>
                        <p>4RB + Terjual</p>
                        <p>KOTA BANDUNG</p>
                        <input type="hidden" id="quantity" name="quantity" value="1"><br>
                        <input type="hidden" name="hidden_image" value="<?php echo $row["image"]; ?>">
                        <input type="hidden" name="hidden_name" value="<?php echo $row["description"]; ?>">
                        <input type="hidden" name="hidden_price" value="<?php echo $row["price"]; ?>">
                        <input type="submit" name="add" value="Add to Cart" class="btn">
                    </form>
                    
                </div>
                <?php
            }
        }
        ?>
<!-- END -->

<!-- PRODUK 11 -->
    <?php
        $query = "SELECT * FROM `tb_degirol` ORDER BY id ASC";
        $result = mysqli_query($conn, $query);

        if (mysqli_num_rows($result) > 0) {
            while ($row = mysqli_fetch_array($result)) {
                ?>
                <div class="box product">
                    <form action="index1.php?action=add&id=<?= $row["id"];?>" method="POST">
                        <a href="#" class="fas fa-heart"></a>
                        <a href="produk/degirol.php" class="fas fa-eye"></a>
                        <img src="ICONS/<?php echo $row["image"]; ?>" alt="">
                        <h3><?php echo $row["description"]; ?></h3>
                        <p>Rp.<?php echo $row["price"]; ?>/Kaplet</p>
                        <p>★★★★☆ (4.7/5)</p>
                        <p>4RB + Terjual</p>
                        <p>KOTA BANDUNG</p>
                        <input type="hidden" id="quantity" name="quantity" value="1"><br>
                        <input type="hidden" name="hidden_image" value="<?php echo $row["image"]; ?>">
                        <input type="hidden" name="hidden_name" value="<?php echo $row["description"]; ?>">
                        <input type="hidden" name="hidden_price" value="<?php echo $row["price"]; ?>">
                        <input type="submit" name="add" value="Add to Cart" class="btn">
                    </form>
                    
                </div>
                <?php
            }
        }
        ?>
<!-- END -->

<!-- PRODUK 12 -->
    <?php
        $query = "SELECT * FROM tb_counterpain ORDER BY id ASC";
        $result = mysqli_query($conn, $query);

        if (mysqli_num_rows($result) > 0) {
            while ($row = mysqli_fetch_array($result)) {
                ?>
                <div class="box product">
                    <form action="index1.php?action=add&id=<?= $row["id"];?>" method="POST">
                        <a href="#" class="fas fa-heart"></a>
                        <a href="produk/counterpain.php" class="fas fa-eye"></a>
                        <img src="ICONS/<?php echo $row["image"]; ?>" alt="">
                        <h3><?php echo $row["description"]; ?></h3>
                        <p>Rp.<?php echo $row["price"]; ?>/Cream</p>
                        <p>★★★★☆ (9/5)</p>
                        <p>4RB + Terjual</p>
                        <p>KOTA BANDUNG</p>
                        <input type="hidden" id="quantity" name="quantity" value="1"><br>
                        <input type="hidden" name="hidden_image" value="<?php echo $row["image"]; ?>">
                        <input type="hidden" name="hidden_name" value="<?php echo $row["description"]; ?>">
                        <input type="hidden" name="hidden_price" value="<?php echo $row["price"]; ?>">
                        <input type="submit" name="add" value="Add to Cart" class="btn">
                    </form>
                    
                </div>
                <?php
            }
        }
        ?>
<!-- END -->

<!-- PRODUK 13 -->
    <?php
        $query = "SELECT * FROM `tb_miconazole` ORDER BY id ASC";
        $result = mysqli_query($conn, $query);

        if (mysqli_num_rows($result) > 0) {
            while ($row = mysqli_fetch_array($result)) {
                ?>
                <div class="box product">
                    <form action="index1.php?action=add&id=<?= $row["id"];?>" method="POST">
                        <a href="#" class="fas fa-heart"></a>
                        <a href="produk/miconazole.php" class="fas fa-eye"></a>
                        <img src="ICONS/<?php echo $row["image"]; ?>" alt="">
                        <h3><?php echo $row["description"]; ?></h3>
                        <p>Rp.<?php echo $row["price"]; ?>/Cream</p>
                        <p>★★★★☆ (9.8/5)</p>
                        <p>18RB + Terjual</p>
                        <p>KOTA BANDUNG</p>
                        <input type="hidden" id="quantity" name="quantity" value="1"><br>
                        <input type="hidden" name="hidden_image" value="<?php echo $row["image"]; ?>">
                        <input type="hidden" name="hidden_name" value="<?php echo $row["description"]; ?>">
                        <input type="hidden" name="hidden_price" value="<?php echo $row["price"]; ?>">
                        <input type="submit" name="add" value="Add to Cart" class="btn">
                    </form>
                    
                </div>
                <?php
            }
        }
        ?>
<!-- END -->
        

    </div>

</section>

<!-- PENUTUP PENJUALAN -->


<!-- REVIEW DESAIN  -->

<section class="review" id="review">

<h3 class="sub-heading"> Kepuasaan Pelanggan </h3>
<h1 class="heading"> Pesannya </h1>

<div class="swiper-container review-slider">

    <div class="swiper-wrapper">
        <div class="swiper-slide slide">
        <i class="fas fa-quote-right" style="color: white;"></i>  <!--TANDA KUTIP -->

            <div class="user">
                <img src="ICONS/cewe (5).png" alt="">
                <div class="user-info">
                    <h3>Steven william</h3>
                    <div class="stars">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                    </div>
                </div>
            </div>
            <p>Toko apotek ini sangat membantu dan profesional. Karyawan mereka selalu ramah dan siap membantu 
                dalam memberikan informasi tentang produk kesehatan. Pilihan obat-obatan dan suplemen kesehatan 
                yang lengkap membuat saya merasa nyaman berbelanja di sini. </p>
        </div>

        <div class="swiper-slide slide">
        <i class="fas fa-quote-right" style="color: white;"></i>  <!--TANDA KUTIP -->

            <div class="user">
                <img src="ICONS/cewe (2).png" alt="">
                <div class="user-info">
                    <h3>Azizah putri</h3>
                    <div class="stars">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                    </div>
                </div>
            </div>
            <p>Toko apotek ini sangat membantu dan profesional. Karyawan mereka selalu ramah dan siap membantu 
                dalam memberikan informasi tentang produk kesehatan. Pilihan obat-obatan dan suplemen kesehatan 
                yang lengkap membuat saya merasa nyaman berbelanja di sini.</p>
        </div>

        <div class="swiper-slide slide">
        <i class="fas fa-quote-right" style="color: white;"></i>  <!--TANDA KUTIP -->

            <div class="user">
                <img src="ICONS/cewe (1).png" alt="">
                <div class="user-info">
                    <h3>Citra Lestari</h3>
                    <div class="stars">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                    </div>
                </div>
            </div>
            <p>Toko apotek ini sangat membantu dan profesional. Karyawan mereka selalu ramah dan siap membantu 
                dalam memberikan informasi tentang produk kesehatan. Pilihan obat-obatan dan suplemen kesehatan 
                yang lengkap membuat saya merasa nyaman berbelanja di sini. </p>
        </div>

        <div class="swiper-slide slide">
        <i class="fas fa-quote-right" style="color: white;"></i> <!--TANDA KUTIP -->

            <div class="user">
                <img src="ICONS/cewe (3).png" alt="">
                <div class="user-info">
                    <h3>Gio Pamungkas</h3>
                    <div class="stars">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                    </div>
                </div>
            </div>
            <p>Toko apotek ini sangat membantu dan profesional. Karyawan mereka selalu ramah dan siap membantu 
                dalam memberikan informasi tentang produk kesehatan. Pilihan obat-obatan dan suplemen kesehatan 
                yang lengkap membuat saya merasa nyaman berbelanja di sini.</p>
        </div>
    </div>

</div>

</section>
<!-- PENUTUP REVIEW -->

<!-- FOOTER  -->
<!-- FOOTER  -->
<footer class="footer">
        <div class="footer-left">
            <h3>Payment Method</h3>
            <div class="credit-cards">
                <img src="ICONS/visa.png" alt="">
                <img src="ICONS/bitcoin.png" alt="">
                <img src="ICONS/BRI.png" alt="">
            </div>
            <p class="footer-copyright"> &copy; All Right Reserved by MyApotek</p>
        </div>

        <div class="footer-center">
            <div>
                <i class="fa fa-map-marker"></i>
                <p><span>Indonesia</span> Jawa Barat, Bandung</p>
            </div>
            <div>
                <i class="fa fa-phone"></i>
                <p>+62 895-3523-08300</p>
            </div>
            <div>
                <i class="fa fa-envelope"></i>
                <p><a href="#">MyApotek12@gmail.com</a></p>
            </div>
        </div>

        <div class="footer-right">
            <p class="footer-about">
                <span>About</span>
                Selamat datang di Toko Apotek, destinasi terpercaya untuk semua kebutuhan kesehatan. 
                Kami berkomitmen menyediakan produk dan layanan kesehatan berkualitas tinggi kepada pelanggan. 
                Dengan rangkaian produk farmasi dll. Kami hadir untuk
                memenuhi kebutuhan kesehatan Anda.
            </p>

            <div class="footer-media">
                <a href="#"><i class="fa fa-facebook"></i></a>
                <a href="#"><i class="fa fa-twitter"></i></a>
                <a href="#"><i class="fa fa-instagram"></i></a>
                <a href="#"><i class="fa fa-whatsapp"></i></a>
            </div>
        </div>

    </footer>
<!-- <footer>(C)All Right Reserved by MyApotek</footer> -->
<!-- FOOTER -->




























<!-- DIAMBIL DARI SWIPER -->
<script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>


<script src="js/script1.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
</body>
</html>
<?php
session_start();
    require 'backend_apotek/konekDB.php';

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CART</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <!-- Bootsratp -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/bxslider/4.2.12/jquery.bxslider.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
        <script src="https://cdn.jsdelivr.net/bxslider/4.2.12/jquery.bxslider.js"></script>
        <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
        <script src="script.js"></script>
        <style>
    body {
        font-family: Arial, sans-serif;
        background-color: #f4f4f4;
        margin: 0;
        padding: 0;
    }

    .container {
        max-width: 800px;
        margin: 0 auto;
        padding: 20px;
        background: rgb(208,239,219);
        background: radial-gradient(circle, rgba(208,239,219,1) 16%, rgba(80,220,228,1) 79%);
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        border-radius: 8px;
        margin-top: 20px;
    }

    h1 {
        text-align: center;
        color: #333;
    }

    form {
        margin-top: 20px;
    }

    label {
        display: block;
        margin-bottom: 5px;
    }

    input,
    textarea,
    select {
        width: 100%;
        padding: 10px;
        margin-bottom: 15px;
        border: 1px solid #ccc;
        border-radius: 4px;
        box-sizing: border-box;
    }

    select {
        height: 50px;
    }

    textarea {
        resize: vertical;
    }

    .checkout {
        text-align: center;
        margin-top: 20px;
    }

    .btn {
        padding: 10px 20px;
        font-size: 16px;
        cursor: pointer;
        border: none;
        border-radius: 4px;
        color: #fff;
    }

    .btn-success {
        background-color: #28a745;
    }
</style>
</head>
<body>
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320">
        <path fill="#87CEFA" fill-opacity="1" d="M0,256L48,218.7C96,181,192,107,288,106.7C384,107,480,181,576,176C672,171,768,85,864,90.7C960,96,1056,192,1152,218.7C1248,245,1344,203,1392,181.3L1440,160L1440,0L1392,0C1344,0,1248,0,1152,0C1056,0,960,0,864,0C768,0,672,0,576,0C480,0,384,0,288,0C192,0,96,0,48,0L0,0Z">
        </path>
    </svg>
        <div class="welcome">
            <div class="container"> 
                <h1>Selesaikan Pesanan Anda Sekarang </h1></div><br>

                <form action="backend_apotek/proses_Checkout.php" method="POST">
                    
                    <input type="hidden" name="id" value="1"> <!-- Gantilah '1' dengan ID aktual dari formulir Anda -->
                <div class="welcome">
                <div class="container">
                    <div class="co">

                    <?php
                        $query = "SELECT * FROM `semua_produk` ORDER BY id ASC";
                        $result = mysqli_query($conn, $query);
                        $cartTotal = 0; // Variabel untuk menyimpan total harga
                        
                        if (mysqli_num_rows($result) > 0) {
                            $row = mysqli_fetch_array($result);

                            // Inisialisasi array produk
                            $produkArray = [];

                            // Loop untuk mengumpulkan data produk
                            while ($row != null) {
                                $produkArray[] = $row;
                                $row = mysqli_fetch_array($result);
                            }
                    ?>

                                <center>
                                    <h3>Detail Pemesanan</h3>

                                    <?php

                                        // Loop melalui array produk
                                        for ($i = 0; $i < count($produkArray); $i++) {
                                            $currentRow = $produkArray[$i];
                                        
                                            // Cek apakah deskripsi produk tidak kosong
                                            if (!empty($currentRow["description"])) {
                                                // Tampilkan label dan input sesuai dengan data produk
                                                echo "<label><h6>Produk " . ($i + 1) . ":</h6></label>";
                                                echo "<input type='text' name='nama_produk" . ($i + 1) . "' value='" . $currentRow["description"] . "' readonly>";
                                                echo "<br>";
                                            }
                                        }
                                    ?>
                                        
                          
                                        <!-- Tampilkan email, nomor telepon, dan alamat dari sesi -->
                                        <label><h6>Nama Lengkap :</h6></label>
                                        <input type="text" name="name" value="<?php echo isset($_SESSION['name']) ? $_SESSION['name'] : ''; ?>" readonly>

                                        <label><h6>No.Handphone :</h6></label>
                                        <input type="tel" name="nomor_handphone" value="<?php echo isset($_SESSION['nope']) ? $_SESSION['nope'] : ''; ?>">

                                        <label><h6>Alamat :</h6></label>
                                        <textarea name="alamat"><?php echo isset($_SESSION['alamat']) ? $_SESSION['alamat'] : ''; ?></textarea>

                                        
                                        
                                        <center>
                                            <h5 class="text-center-lead" >Pilih Metode Pembayaran</h5></center><br>
                                            <div class="form-group">
                                                <select name="pmode" class="form-control" style="height: 50px;">
                                                    <option value=""> Pilih Pembayaran </option>
                                                    <option value="Cash on Delivery"> Cash on Delivery </option>
                                                    <option value="E-Wallet"> E-Wallet </option>
                                                    <option value="Debit/Credit Card"> Debit/Credit Card </option>
                                                </select>
                                            </div> <br><br>
                                            <center>
                                            <h5 class="text-center-lead" >Pilih Metode Pengiriman </h5></center><br>
                                            <div class="form-group">
                                                <select name="pmode1" class="form-control" style="height: 50px;">
                                                    <option value=""> Pilih Ekspedisi </option>
                                                    <option value="JNE Express"> JNE Express </option>
                                                    <option value="JNT Express"> JNT Express </option>
                                                    <option value="Ninja Express"> Ninja Express </option>
                                                    <option value="SiCepat"> SiCepat </option>
                                                </select>
                                            </div>
                                            <br> 
                        
                                                <h4>Total Pesanan:
                                                <?php

                                                    if(isset($_SESSION['total'])) {
                                                        $total = $_SESSION['total'];
                                                    } else {
                                                        $total = 0;
                                                    }
                                    
                                                echo number_format ($total,3);
                                                ?>
                                                </h4>

        
                                                

                                 </center>

                                <?php
                        
                        }
                    ?>

                    
        </div>
        </div>
        </div>
                                
                    
                    <div class="checkout">
                    <button type="submit" class="btn btn-success" onclick="window.location.href='backend_apotek/sessionCart.php'">Konfirmasi Pemesanan</button>
                    <button type="button" class="btn btn-success" onclick="window.location.href='backend_apotek/sessionCart.php'">Ganti Pesanan</button>
        </div>
                </form>


    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320">
        <path fill="#87CEFA" fill-opacity="1" d="M0,256L48,234.7C96,213,192,171,288,176C384,181,480,235,576,224C672,213,768,139,864,133.3C960,128,1056,192,1152,218.7C1248,245,1344,235,1392,229.3L1440,224L1440,320L1392,320C1344,320,1248,320,1152,320C1056,320,960,320,864,320C768,320,672,320,576,320C480,320,384,320,288,320C192,320,96,320,48,320L0,320Z">
        </path>
    </svg>
            </div>
        </div>






       
</body>
</html>
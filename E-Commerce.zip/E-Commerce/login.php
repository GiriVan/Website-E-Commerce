<?php 
session_start();
    require 'backend_apotek/konekdb.php';

    if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submit'])) {
        // Proses data formulir dan atur variabel sesi
        $_SESSION['name'] = $_POST['name'];
    }

// if(isset($_SESSION['username'])) { //UNTUK MEMUNCULKAN USERNAME PAS DI HALAMAN CHECKOUT JADI MENGGUNAKAN SESSION
//     header("Location: detailCO.php");
//     exit; 
// }

if(isset($_POST["submit"]) ) {

    $username = $_POST["name"];
    $password = $_POST["password"];

    $query = "SELECT * FROM login WHERE username = '$username' AND password = '$password'";

    $cek = mysqli_query($conn, $query);
    $konek = mysqli_fetch_assoc($cek);
    if($konek > 0 ) {

        $_SESSION['username'] = $username; // Simpan username ke sesi

        echo "<script> 
                alert('login anda berhasil');
                window.location='detailCO1.php';
                
                </script>";
            }else{
                echo "<script> 
                alert('login gagal');
                window.location='login.php';
                
            </script>";

    }

}
?>



<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
    <style>
        /* Gaya CSS untuk tata letak dan tampilan container login */
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-size: contain;
            background-repeat: no-repeat;
            background-position: center; 
            background: rgb(208,239,219);
            background: radial-gradient(circle, rgba(208,239,219,1) 16%, rgba(80,220,228,1) 79%);
            background-size: 100% auto;
           
           
            
        }
        
        .login-container {
            max-width: 400px;
            margin: 100px auto;
            padding: 20px;
            background-color: rgba(255, 255, 255, 0.8);
            color: white;
            text-align: center;
            border-radius:20px;
            margin-top:170px;
           
        }
        h2{
            color: black;
        }
        .login-container h2 {
            margin-top: 0;
            
        }
        
        .logo-icon {
            width: 50px;
            height: 50px;
            margin-bottom: 20px;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-group label {
            display: block;
            width:50px;
        }
        
        .form-group input[type="text"],
        .form-group input[type="password"] {
            width: 50%;
            padding: 10px;
            border-radius:10px;
        }
        
        .form-group .logo-icon-small {
            width: 20px;
            height: 20px;
            margin-left: 5px;
        }
        
        .login-button {
            padding: 10px 20px;
            background-color: black;
            color: #fff;
            border: none;
            cursor: pointer;
            text-decoration:none;
            border-radius: 4px;
        }
        
        .login-button:hover{
            background-color:grey;
        }

        .register-text {
            text-align: center;
            margin-top: 20px;
            color: black;
        }

        .register-link {
            color: #4CAF50;
            text-decoration: none;
            font-weight: bold;
        }

        .register-link:hover {
        color: black;
        }
    </style>
</head>

<body>
    <div class="login-container">
        <h2>FORM LOGIN</h2>
        <form method="POST" action="">
            <div class="form-group">
                <input type="text" id="username" name="name" placeholder="username">
            </div>
            <div class="form-group">
                <input type="password" id="password" name="password" placeholder="password">
            </div>
            <button class="login-button" type="submit" id="btn-register" name="submit">Login</button>
        <div class="register-text">
            Belum punya akun? <a class="register-link" href="register.php">Register </a> sekarang
        </div>
           
        </form>
    </div>
</body>
</html>
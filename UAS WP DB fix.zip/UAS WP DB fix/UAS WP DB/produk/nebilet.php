<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Apotek Kami</title>

    <!-- FONT AWESOME CDN LINK -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">

    <!-- SWIPER UNTUK BISA NGE SLIDER-->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css">

    <!-- HUBUNGKAN KE CSS -->
    <link rel="stylesheet" href="css/style2.css">

    <style>
   .product-image {
    float: left;
    margin-right: 100px;
    max-width: 100%;
    width: 400px;
}
.product-image img {
    max-width: 100%;
    height: auto;
    border-radius: 8px;
    width: 100%;
}


    </style>

</head>
<body>

    <!-- header -->
    <header>
        
        <a href="#" class="logo"><i class="fa fa-hospital"></i>Apotek.</a>

        <nav class="navbar">
            <a class="" href="#home">Home</a>
            <a href="#about">About</a>
            <a href="#obat">Product</a>
            <a href="#review">Review</a>           
        </nav>

        <div class="icons">
            <i class="fas fa-bars" id="menu-bars"></i>
            <i class="fas fa-search" id="search-icon"></i>
            <a href="#" class="fas fa-heart"></a>
            <a href="#" class="fas fa-shopping-cart"></a>
        </div>

    </header>
<!-- END HEADER -->

<!-- UNTUK MEMBUAT TAMPILAN SEARCH -->
<form action="" id="search-form">
    <input type="search" placeholder="carii disniii" name="" id="sercing">
    <label for="sercing" class="fas fa-search"></label>
    <i class="fas fa-times" id="close"></i>
</form>
<!-- END SEARCH -->

    <div class="container">
        <div class="product-details">
            <div class="product-image">
                <img src="../ICONS/Obat Nabilet.png" alt="Gambar Produk">
            </div>
            <div class="product-info">
                <h1>Nebilet 5 mg 14 Tablet</h1>
                <span>Rp.135.000/strip</span>
                <a href="../index1.php?#obat" class="btn">Pembelian</a>
                <div class="product-details-section">
                    <h2>Deskripsi</h2>
                    <p> NEBILET merupakan obat kardiovaskular yang mengandung Nebivolol 5 mg. Nebivolol merupakan golongan beta-blocker selektif. Obat ini digunakan untuk hipertensi, mencegah stroke, serangan jantung, serta mengobati gagal jantung kronik pada pasien berumur diatas 70 tahun. Obat ini bekerja dengan cara mencegah meningkatnya denyut jantung, mengontrol kekuatan pompa jantung, dan dilatasi pembuluh darah.</p>
                    <h2>Indikasi Umum</h2>
                    <p>Pengobatan hipertensi esensial & gagal jantung kronis ringan & sedang stabil selain terapi standar pada pasien usia lanjut.</p>
                    <h2>komposisi</h2>
                    <p>Nebivolol HCl 5 mg</p>
                    <h2>Dosis</h2>
                    <p>Hipertensi : Dewasa : 5 mg sekali sehari. Dalam kombinasi dengan agen antihipertensi lain 5 mg ditambah hidroklorotiazid 12,5-25 mg. Lansia lebih dari 65 tahun Mulai 2,5 mg setiap hari. Dapat ditingkatkan menjadi 5 mg setiap hari.</p>
                    <h2>Aturan Pakai :</h2>
                    <p>Dikonsumsi bersama makanan dan dengan waktu yang sama.</p>
                    <h2>Perhatian</h2>
                    <p>Penggunaan bersamaan dengan anestesi. CHF yang tidak diobati, penyakit jantung iskemik.</p>
                    <h2>Kontra Indikasi</h2>
                    <p>Hipersensitivitas. Insufisiensi atau gangguan hati. Gagal jantung akut, syok kardiogenik atau episode dekompensasi gagal jantung.</p>
                    <h2>Efek Samping</h2>
                    <p>Sakit kepala, pusing, parestesia; dispnea; sembelit, mual, diare; kelelahan, edema.</p>
                    <h2>Golongan Produk</h2>
                    <p>Obat Keras (Merah)</p>
                    <h2>Kemasan</h2>
                    <p>Dus, 2 Blister @ 14 tablet</p>
                    <h2>Manufaktur</h2>
                    <p>Menarini Indria Laboratories</p>
                    <h2>No. Registrasi</h2>
                    <p>BPOM: DKI1529800210A1</p>
                </div>
                
            </div>
        </div>
    </div>
</body>
</html>

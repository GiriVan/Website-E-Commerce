<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Apotek Kami</title>

    <!-- FONT AWESOME CDN LINK -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">

    <!-- SWIPER UNTUK BISA NGE SLIDER-->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css">

    <!-- HUBUNGKAN KE CSS -->
    <link rel="stylesheet" href="css/style2.css">

    <style>
.product-image {
    float: left;
    margin-right: 100px;
    max-width: 100%;
    width: 400px;
}
.product-image img {
    max-width: 100%;
    height: auto;
    border-radius: 8px;
    width: 100%;
}


    </style>

</head>
<body>

    <!-- header -->
    <header>
        
        <a href="#" class="logo"><i class="fa fa-hospital"></i>Apotek.</a>

        <nav class="navbar">
            <a class="" href="#home">Home</a>
            <a href="#about">About</a>
            <a href="#obat">Product</a>
            <a href="#review">Review</a>           
        </nav>

        <div class="icons">
            <i class="fas fa-bars" id="menu-bars"></i>
            <i class="fas fa-search" id="search-icon"></i>
            <a href="#" class="fas fa-heart"></a>
            <a href="#" class="fas fa-shopping-cart"></a>
        </div>

    </header>
<!-- END HEADER -->

<!-- UNTUK MEMBUAT TAMPILAN SEARCH -->
<form action="" id="search-form">
    <input type="search" placeholder="carii disniii" name="" id="sercing">
    <label for="sercing" class="fas fa-search"></label>
    <i class="fas fa-times" id="close"></i>
</form>
<!-- END SEARCH -->

    <div class="container">
        <div class="product-details">
            <div class="product-image">
                <img src="../ICONS/Obat Combivent.png" alt="Gambar Produk">
            </div>
            <div class="product-info">
                <h1>Combantrin Jeruk Sirup 10 ml</h1>
                <span>Rp.25.000/botol</span>
                <a href="../index1.php?#obat" class="btn">Pembelian</a>
                <div class="product-details-section">
                    <h2>Deskripsi</h2>
                    <p>COMBANTRIN JERUK SIRUP merupakan obat cacing yang digunakan untuk mengatasi cacing kremi (Enterobius vermicularis), cacing gelang (Ascaris lumbricoides), cacing tambang (Ancylostoma duodenale), Cacing tambang (Necator americanus), cacing Trichostrongyfus colubriformis dan Trichostrongylus orientalls. Obat ini mengandung zat aktif Pirantel Pamoat yang bekerja dengan melumpuhkan cacing dan mengeluarkannya dari dalam tubuh melalui tinja, biasanya tanpa memerlukan pencahar.</p>
                    <h2>Indikasi Umum</h2>
                    <p>Obat cacing yang digunakan untuk mengatasi infeksi cacing kremi (enterobius vermicularis), cacing gelang (ascaris lumbricoides), cacing tambang (ancylostoma duodenale), cacing tambang (necator americanus), cacing trichostrongylus colubriformis dan trichostrongylus orientalis.</p>
                    <h2>komposisi</h2>
                    <p>Setiap sendok takar (5 ml) mengandung Pirantel Pamoat setara dengan Pirantel base 125 mg.</p>
                    <h2>Dosis</h2>
                    <p>Anak usia 2-6 tahun: 5-10 ml, diberikan sekali. Anak usia 6-12 tahun: 10-15 ml, diberikan sekali. Di atas usia 12 tahun: 15-20 ml, diberikan sekali.</p>
                    <h2>Aturan Pakai :</h2>
                    <p>Dapat dikonsumsi sebelum atau sesudah makan</p>
                    <h2>Perhatian</h2>
                    <p>Sebaiknya hindarkan penggunaan Combantrin semasa hamil dan anak usia dibawah 2 tahun karena kemanan penggunaannya belum diteliti / banyak diketahui. Penggunaan Combantrin pada penderita gangguan hati sebaiknya berhati-hati. Pemberian dengan piperazine dapat menyebabkan efek antagonis.</p>
                    <h2>Kontra Indikasi</h2>
                    <p>Penderita hipersensitif.</p>
                    <h2>Efek Samping</h2>
                    <p>Pemakaian obat umumnya memiliki efek samping tertentu dan sesuai dengan masing-masing individu. Jika terjadi efek samping yang berlebih dan berbahaya, harap konsultasikan kepada tenaga medis. Efek samping yang mungkin terjadi dalam penggunaan obat adalah: Anoreksia (Nafsu makan hilang), mual, muntah, diare, sakit kepala, pusing, rasa mengantuk, merah-merah pada kulit, keringat dingin, pruritus, urtikaria.</p>
                    <h2>Golongan Produk</h2>
                    <p>Obat Bebas Terbatas (Biru)</p>
                    <h2>Kemasan</h2>
                    <p>Dus, Botol @ 10 ml</p>
                    <h2>Manufaktur</h2>
                    <p>Pfizer</p>
                    <h2>No. Registrasi</h2>
                    <p>BPOM: DTL8819801933A1</p>
                </div>
                
            </div>
        </div>
    </div>
</body>
</html>

<?php

require '../backend_apotek/konekDB.php';

if(!$conn){
    echo "Failed to Connect";
}

if(isset($_POST["add"])){
    $producId = $_GET["id"];
    $productName = $_POST["hidden_name"];
    $productImage = $_POST["hidden_image"];
    $productPrice = $_POST["hidden_price"];
    $productQuantity = $_POST["quantity"];

    $sql = "INSERT INTO `product_second` (`description`, `image`, `price`, `quantity`) VALUES ('$productName', '$productImage', '$productPrice', '$productQuantity');";
    $konek = mysqli_query($conn, $sql);
    if ($konek > 0) {
        echo "<script> 
                alert('Sudah masuk kedalam keranjang');
                
                </script>";
            }else{
                echo "<script> 
                alert('gagal masuk kedalam keranjang');
                
                
            </script>";
        }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Apotek Kami</title>

    <!-- FONT AWESOME CDN LINK -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">

    <!-- SWIPER UNTUK BISA NGE SLIDER-->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css">

    <!-- HUBUNGKAN KE CSS -->
    <link rel="stylesheet" href="css/style.css">

    <style>
   body {
    margin: 0;
    padding: 20;
    font-family: 'Arial', sans-serif;
    background: radial-gradient(circle, rgba(208,239,219,1) 16%, rgba(80,220,228,1) 79%);
    color: #fff;
}

.container {
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 100vh;
}

.product-details {
    display: flex;
    align-items: center;
}

.product-image img {
    max-width: 100%;
    margin-right: 20px;
}

.product-info {
    max-width: 600px;
}

.product-info h1 {
    font-size: 24px;
    margin-bottom: 10px;
}

.product-info span {
    font-size: 18px;
    color: #ffd700;
    display: block;
    margin-bottom: 20px;
}

.btn {
    display: inline-block;
    padding: 10px 20px;
    background-color: #ffd700;
    color: #192a56;
    text-decoration: none;
    border-radius: 5px;
    font-size: 16px;
}

.product-details-section {
    margin-top: 30px;
}

.product-details-section h2 {
    font-size: 20px;
    margin-bottom: 10px;
}

.product-details-section p {
    font-size: 16px;
    margin-bottom: 15px;
}


    </style>

</head>
<body>

    <!-- header -->
    <header>
        
        <a href="#" class="logo"><i class="fa fa-hospital"></i>Apotek.</a>

        <nav class="navbar">
            <a class="" href="#home">Home</a>
            <a href="#about">About</a>
            <a href="#obat">Product</a>
            <a href="#review">Review</a>           
        </nav>

        <div class="icons">
            <i class="fas fa-bars" id="menu-bars"></i>
            <i class="fas fa-search" id="search-icon"></i>
            <a href="#" class="fas fa-heart"></a>
            <a href="../cart.php" class="fas fa-shopping-cart"></a>
        </div>

    </header>
<!-- END HEADER -->

<!-- DESKRIPSI -->
    <div class="container">
        <div class="product-details">
            <div class="product-image">
                <img src="../ICONS/19 - Degirol.png" alt="Gambar Produk">
            </div>
            <div class="product-info">
                <h1>Degirol Hisap 0,25 mg 10 Tablet</h1>
                <span>Rp12.600 - Rp18.800/strip</span>

                <a href="../index1.php?#obat" class="btn">Pembelian</a>
                <div class="product-details-section">
                    <h2>Deskripsi</h2>
                    <p>DEGIROL merupakan tablet hisap yang mengandung Dequalinium Chloride. Obat ini digunakan untuk mengobati sakit tenggorokan, radang atau infeksi pada rongga mulut dan tenggorokan, serta pencegahan flu dan batuk.</p>
                    <h2>Indikasi Umum</h2>
                    <p>Obat ini digunakan untuk sakit tenggorokan, peradangan pada rongga mulut dan tenggorokan seperti gingivitis, periodontitis, faringitis, laringitis dan angina, serta infeksi selaput lendir mulut seperti stomatitis.</p>
                    <h2>komposisi</h2>
                    <p>Setiap tablet hisap mengandung Dequalinium Chloride 0.25 mg</p>
                    <h2>Dosis</h2>
                    <p>Dewasa: 1 tablet dihisap, tiap 3 - 4 jam. Maksimal 8 tablet per hari.</p>
                    <h2>Aturan Pakai :</h2>
                    <p>Satu tablet dibiarkan melarut perlahan-lahan di dalam mulut.</p>
                    <h2>Perhatian</h2>
                    <p>Hindari pemakaian jangka panjang dan berulang. Belum terdapat data keamanan terkait penggunaan obat ini pada wanita hamil dan/atau menyusui. Konsultasikan kepada dokter apabila Anda sedang hamil dan/atau menyusui.</p>
                    <h2>Kontra Indikasi</h2>
                    <p>Penderita Hipersensitif atau alergi terhadap Dequalinium Chloride.</p>
                    <h2>Efek Samping</h2>
                    <p>Pemakaian obat umumnya memiliki efek samping tertentu dan sesuai dengan masing-masing individu. Jika terjadi efek samping yang berlebih dan berbahaya, harap konsultasikan kepada tenaga medis.</p>
                    <h2>Golongan Produk</h2>
                    <p>Obat Bebas (Hijau)</p>
                    <h2>Kemasan</h2>
                    <p>Dus, Amplop @ 1 Strip @ 10 tablet</p>
                    <h2>Manufaktur</h2>
                    <p>Darya Varia Laboratoria</p>
                    <h2>No. Registrasi</h2>
                    <p>BPOM: DBL9104508712A1</p>
                </div>
                
            </div>
        </div>
    </div>
<!-- END DESKRIPSI -->

    
</body>
</html>

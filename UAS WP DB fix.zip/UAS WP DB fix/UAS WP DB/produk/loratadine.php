<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Apotek Kami</title>

    <!-- FONT AWESOME CDN LINK -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">

    <!-- SWIPER UNTUK BISA NGE SLIDER-->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css">

    <!-- HUBUNGKAN KE CSS -->
    <link rel="stylesheet" href="css/style2.css">

    <style>
   

    </style>

</head>
<body>

    <!-- header -->
    <header>
        
        <a href="#" class="logo"><i class="fa fa-hospital"></i>Apotek.</a>

        <nav class="navbar">
            <a class="" href="#home">Home</a>
            <a href="#about">About</a>
            <a href="#obat">Product</a>
            <a href="#review">Review</a>           
        </nav>

        <div class="icons">
            <i class="fas fa-bars" id="menu-bars"></i>
            <i class="fas fa-search" id="search-icon"></i>
            <a href="#" class="fas fa-heart"></a>
            <a href="#" class="fas fa-shopping-cart"></a>
        </div>

    </header>
<!-- END HEADER -->

<!-- UNTUK MEMBUAT TAMPILAN SEARCH -->
<form action="" id="search-form">
    <input type="search" placeholder="carii disniii" name="" id="sercing">
    <label for="sercing" class="fas fa-search"></label>
    <i class="fas fa-times" id="close"></i>
</form>
<!-- END SEARCH -->

    <div class="container">
        <div class="product-details">
            <div class="product-image">
                <img src="../ICONS/Obat Larotadine.png" alt="Gambar Produk">
            </div>
            <div class="product-info">
                <h1>Loratadine 10 mg 10 Tablet</h1>
                <span>Rp.5.500/strip</span>
                <a href="../index1.php?#obat" class="btn">Pembelian</a>
                <div class="product-details-section">
                    <h2>Deskripsi</h2>
                    <p>LORATADINE 10 MG merupakan turunan piperidin, yakni antihistamin non-sedatif kerja panjang yang secara selektif menghambat reseptor histamin H1 pada sel efektor. Loratadin digunakan untuk gejala alergi seperti hay fever, urtikaria. Dalam menggunakan obat ini HARUS SESUAI DENGAN PETUNJUK DOKTER. Pembelian obat ini memerlukan edukasi terkait penggunaan atau pengonsumsian obat yang tepat dan aman yang akan dikenakan biaya.</p>
                    <h2>Indikasi Umum</h2>
                    <p>INFORMASI OBAT INI HANYA UNTUK KALANGAN MEDIS. Obat ini digunakan untuk meredakan gejala alergi seperti hay fever, urtikaria.</p>
                    <h2>komposisi</h2>
                    <p>Loratadine 10 mg</p>
                    <h2>Dosis</h2>
                    <p>Dewasa dan anak usia lebih dari 12 tahun : 10 mg sekali sehari atau 5 mg dua kali sehari. Anak usia 2-12 tahun : BB kurang dari 30 kg: 5 mg sekali sehari. BB lebih dari 30: 10 mg, sekali sehari.</p>
                    <h2>Aturan Pakai :</h2>
                    <p>Dikonsumsi sebelum atau sesudah makan.</p>
                    <h2>Perhatian</h2>
                    <p>Hati-hati penggunaan pada pasien dengan gangguan hati dan ginjal yang parah. Anak-anak. Kehamilan dan menyusui.</p>
                    <h2>Kontra Indikasi</h2>
                    <p>Hipersensitif terhadap Loratadine.</p>
                    <h2>Efek Samping</h2>
                    <p>Efek samping yang mungkin terjadi dalam penggunaan obat adalah: signifikan: Sakit kepala, mengantuk, mengantuk, kelelahan, gugup. Gangguan jantung: Palpitasi, takikardia, hipotensi.</p>
                    <h2>Golongan Produk</h2>
                    <p>Obat Keras (Merah)</p>
                    <h2>Kemasan</h2>
                    <p>Dus, 5 Strip @ 10 Tablet</p>
                    <h2>Manufaktur</h2>
                    <p>Generic Manufacturer</p>
                    <h2>No. Registrasi</h2>
                    <p>BPOM: GKL1616704304A1</p>
                </div>
                
            </div>
        </div>
    </div>
</body>
</html>

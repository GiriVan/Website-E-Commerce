<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Apotek Kami</title>

    <!-- FONT AWESOME CDN LINK -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">

    <!-- SWIPER UNTUK BISA NGE SLIDER-->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css">

    <!-- HUBUNGKAN KE CSS -->
    <link rel="stylesheet" href="css/style2.css">

    <style>
   

    </style>

</head>
<body>

    <!-- header -->
    <header>
        
        <a href="#" class="logo"><i class="fa fa-hospital"></i>Apotek.</a>

        <nav class="navbar">
            <a class="active" href="#home">Home</a>
            <a href="#about">About</a>
            <a href="#obat">Product</a>
            <a href="#review">Review</a>           
        </nav>

        <div class="icons">
            <i class="fas fa-bars" id="menu-bars"></i>
            <i class="fas fa-search" id="search-icon"></i>
            <a href="#" class="fas fa-heart"></a>
            <a href="#" class="fas fa-shopping-cart"></a>
        </div>

    </header>
<!-- END HEADER -->

<!-- UNTUK MEMBUAT TAMPILAN SEARCH -->
<form action="" id="search-form">
    <input type="search" placeholder="carii disniii" name="" id="sercing">
    <label for="sercing" class="fas fa-search"></label>
    <i class="fas fa-times" id="close"></i>
</form>
<!-- END SEARCH -->

    <div class="container">
        <div class="product-details">
            <div class="product-image">
                <img src="../ICONS/Obat Paracetamol.png" alt="Gambar Produk">
            </div>
            <div class="product-info">
                <h1>Paracetamol 500 mg 10 Kaplet</h1>
                <span>Rp.5.000/strip</span>
                <a href="../index1.php?#obat" class="btn">Pembelian</a>
                <div class="product-details-section">
                    <h2>Deskripsi</h2>
                    <p>PARACETAMOL TABLET merupakan obat yang dapat digunakan untuk meringankan rasa sakit pada sakit kepala, sakit gigi, dan menurunkan demam. Paracetamol bekerja pada pusat pengatur suhu di hipotalamus untuk menurunkan suhu tubuh (antipiretik) serta menghambat sintesis prostaglandin sehingga dapat mengurangi nyeri ringan sampai sedang (analgesik)</p>
                    <h2>Indikasi Umum</h2>
                    <p>Obat ini digunakan untuk meredakan nyeri ringan hingga sedang seperti sakit kepala, sakit gigi, nyeri otot, serta menurunkan demam.</p>
                    <h2>komposisi</h2>
                    <p>Setiap tablet mengandung Paracetamol 500 mg</p>
                    <h2>Dosis</h2>
                    <p>Dewasa: 1-2 kaplet, 3-4 kali per hari. Penggunaan maximum 8 kaplet per hari. Anak 7-12 tahun : 0.5 - 1 kaplet, 3-4 kali per hari. Penggunaan maximum 4 kaplet per hari.</p>
                    <h2>Aturan Pakai :</h2>
                    <p>Obat dapat diminum sebelum atau sesudah makan</p>
                    <h2>Perhatian</h2>
                    <p>Hati-hati penggunaan pada pasien dengan gagal ginjal, gangguan fungsi hati, dan alergi atau mengalami hipersensitivitas terhadap paracetamol. Kategori kehamilan : Kategori B: Mungkin dapat digunakan oleh wanita hamil. Penelitian pada hewan uji tidak memperlihatkan ada nya risiko terhadap janin, namun belum ada bukti penelitian langsung terhadap wanita hamil.</p>
                    <h2>Kontra Indikasi</h2>
                    <p>Parasetamol jangan diberikan kepada penderita hipersensitif/alergi terhadap Paracetamol. Penderita gangguan fungsi hati berat.</p>
                    <h2>Efek Samping</h2>
                    <p>Pemakaian obat umumnya memiliki efek samping tertentu dan sesuai dengan masing-masing individu. Jika terjadi efek samping yang berlebih dan berbahaya, harap konsultasikan kepada tenaga medis. Efek samping yang mungkin terjadi dalam penggunaan obat adalah: - Penggunaan untuk jangka waktu lama dan dosis besar dapat menyebabkan kerusakan fungsi hati. - Reaksi hipersensitifitas/ alergi.</p>
                    <h2>Golongan Produk</h2>
                    <p>Obat Bebas (Hijau)</p>
                    <h2>Kemasan</h2>
                    <p>Dus, 10 Strip @ 10 Tablet</p>
                    <h2>Manufaktur</h2>
                    <p>Generic Manufacturer</p>
                    <h2>No. Registrasi</h2>
                    <p>BPOM: GBL7802318304A2</p>
                </div>
                
            </div>
        </div>
    </div>
</body>
</html>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Apotek Kami</title>

    <!-- FONT AWESOME CDN LINK -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">

    <!-- SWIPER UNTUK BISA NGE SLIDER-->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css">

    <!-- HUBUNGKAN KE CSS -->
    <link rel="stylesheet" href="css/style2.css">

    <style>
.product-image {
    float: left;
    margin-right: 100px;
    max-width: 100%;
    width: 400px;
}
.product-image img {
    max-width: 100%;
    height: auto;
    border-radius: 8px;
    width: 100%;
}


    </style>

</head>
<body>

    <!-- header -->
    <header>
        
        <a href="#" class="logo"><i class="fa fa-hospital"></i>MyApotek.</a>

        <nav class="navbar">
            <a class="" href="#home">Home</a>
            <a href="#about">About</a>
            <a href="#obat">Product</a>
            <a href="#review">Review</a>           
        </nav>

        <div class="icons">
            <i class="fas fa-bars" id="menu-bars"></i>
            <i class="fas fa-search" id="search-icon"></i>
            <a href="#" class="fas fa-heart"></a>
            <a href="#" class="fas fa-shopping-cart"></a>
        </div>

    </header>
<!-- END HEADER -->

<!-- UNTUK MEMBUAT TAMPILAN SEARCH -->
<form action="" id="search-form">
    <input type="search" placeholder="carii disniii" name="" id="sercing">
    <label for="sercing" class="fas fa-search"></label>
    <i class="fas fa-times" id="close"></i>
</form>
<!-- END SEARCH -->
<div class="container">
<div class="product-details">
            <div class="product-image">
                <img src="../ICONS/16 - Alendronate.png" alt="Gambar Produk">
            </div>
            <div class="product-info">
                <h1>Alendronate - Alovell 10 Mg 10 Tablet</h1>
                <span>Rp.149.20/Satuan</span>
                    <a href="../index1.php?#obat" class="btn">Pembelian</a>
            
                <div class="product-details-section">
                    <h2>Deskripsi</h2>
                    <p>Pembelian obat ini memerlukan edukasi terkait penggunaan atau pengonsumsian obat yang tepat dan aman yang akan dikenakan biaya.</p>
                    <h2>Indikasi Umum</h2>
                    <p>Osteoporosis pada wanita pasca menopause.</p>
                    <h2>komposisi</h2>
                    <p>Alendronate Na 10 mg</p>
                    <h2>Dosis</h2>
                    <p>PENGGUNAAN OBAT INI HARUS SESUAI DENGAN PETUNJUK DOKTER. 1 kali sehari 10 mg.</p>
                    <h2>Aturan Pakai :</h2>
                    <p>Berikan dengan segelas air sekurang-kurangnya 1/2 jam sebelum konsumsi makanan/minuman/obat pertama kali pada hari yang sama dan tetap dalam posisi dudut/tegak selama sekurang-kurangnya 1/2 jam. Telan utuh, jangan dikunyah atau dihancurkan.</p>
                    <h2>Perhatian</h2>
                    <p>HARUS DENGAN RESEP DOKTER. Disfagia, penyakit esofagus, gastritis, duodenitis, tukak, insufisiensi ginjal.</p>
                    <h2>Kontra Indikasi</h2>
                    <p>Abnormalitas esofagus dengan keterlambatan pengosongan seperti striktur atau akalasia; ketidakmampuan untuk berdiri atau duduk tegak selama min 30 menit; hipokalemia; gangguan ginjal. Hamil; laktasi; anak.</p>
                    <h2>Efek Samping</h2>
                    <p>Nyeri dan distensi abdomen, diare atau konstipasi, kembung, nyeri muskuloskletal, sakit kepala.</p>
                    <h2>Golongan Produk</h2>
                    <p>Obat Keras (Merah)</p>
                    <h2>Kemasan</h2>
                    <p>Tablet 10 mg x 3 x 10</p>
                    <h2>Manufaktur</h2>
                    <p>Novell Pharmaceutical Laboratories</p>
                    <h2>No. Registrasi</h2>
                    <p>BPOM: DKL9933500810A1</p>
                </div>
                
            </div>
        </div>
    </div>
</body>
</html>

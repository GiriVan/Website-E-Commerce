<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Apotek Kami</title>

    <!-- FONT AWESOME CDN LINK -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">

    <!-- SWIPER UNTUK BISA NGE SLIDER-->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css">

    <!-- HUBUNGKAN KE CSS -->
    <link rel="stylesheet" href="css/style2.css">

    <style>
.product-image {
    float: left;
    margin-right: 70px;
    max-width: 100%;
    width: 450px;
}
.product-image img {
    max-width: 100%;
    height: auto;
    border-radius: 8px;
    width: 100%;
}   

    </style>

</head>
<body>

    <!-- header -->
    <header>
        
        <a href="#" class="logo"><i class="fa fa-hospital"></i>Apotek.</a>

        <nav class="navbar">
            <a class="" href="#home">Home</a>
            <a href="#about">About</a>
            <a href="#obat">Product</a>
            <a href="#review">Review</a>           
        </nav>

        <div class="icons">
            <i class="fas fa-bars" id="menu-bars"></i>
            <i class="fas fa-search" id="search-icon"></i>
            <a href="#" class="fas fa-heart"></a>
            <a href="#" class="fas fa-shopping-cart"></a>
        </div>

    </header>
<!-- END HEADER -->

<!-- UNTUK MEMBUAT TAMPILAN SEARCH -->
<form action="" id="search-form">
    <input type="search" placeholder="carii disniii" name="" id="sercing">
    <label for="sercing" class="fas fa-search"></label>
    <i class="fas fa-times" id="close"></i>
</form>
<!-- END SEARCH -->

    <div class="container">
        <div class="product-details">
            <div class="product-image">
                <img src="../ICONS/20 - counterpain.png" alt="Gambar Produk">
            </div>
            <div class="product-info">
                <h1>Counterpain Cream 15 g + Counterpain Cool Gel 5 g</h1>
                <span>Rp.31.000/paket</span>
                <a href="../index1.php?#obat" class="btn">Pembelian</a> <br><br><br><br><br><br><br><br>
                <div class="product-details-section">
                    <h2>Deskripsi</h2>
                    <p>Counterpain Cream: Membantu meredakan nyeri pada otot, sendi, nyeri, keseleo dan encok. Counterpain Cool Gel: Digunakan untuk meredakan nyeri otot dan nyeri sendi yang berhubungan dengan terkilir, memar dan cedera pada saat olahraga.</p>
                    <h2>Indikasi Umum</h2>
                    <p> Untuk meringankan sakit pada otot, sendi, nyeri, keseleo dan encok.</p>
                    <h2>komposisi</h2>
                    <p>Counterpain Cream 15 g: Methyl salicylate 102 mg, Menthol 54.4 mg, Eugenol 13.6 mg Counterpain Cool Gel 5 g: Menthol 4%</p>
                    <h2>Dosis</h2>
                    <p>Sesuai kebutuhan</p>
                    <h2>Aturan Pakai :</h2>
                    <p>Oleskan 3-4 kali sehari. Oleskan pada bagian tubuh yang perlu.</p>
                    <h2>Perhatian</h2>
                    <p>-</p>
                    <h2>Kontra Indikasi</h2>
                    <p>-</p>
                    <h2>Efek Samping</h2>
                    <p>-</p>
                    <h2>Golongan Produk</h2>
                    <p>Produk Konsumen</p>
                    <h2>Kemasan</h2>
                    <p>Per Paket: 1 Counterpain Cream 15 g 1 Counterpain Cool Gel 5 g</p>
                    <h2>Manufaktur</h2>
                    <p>Taisho Pharmaceutical</p>
                    <h2>No. Registrasi</h2>
                    <p>BPOM: QD111709511</p>
                </div>
                
            </div>
        </div>
    </div>
</body>
</html>

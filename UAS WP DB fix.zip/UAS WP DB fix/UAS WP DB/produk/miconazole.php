<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Apotek Kami</title>

    <!-- FONT AWESOME CDN LINK -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">

    <!-- SWIPER UNTUK BISA NGE SLIDER-->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css">

    <!-- HUBUNGKAN KE CSS -->
    <link rel="stylesheet" href="css/style2.css">

    <style>
   

    </style>

</head>
<body>

    <!-- header -->
    <header>
        
        <a href="#" class="logo"><i class="fa fa-hospital"></i>Apotek.</a>

        <nav class="navbar">
            <a class="" href="#home">Home</a>
            <a href="#about">About</a>
            <a href="#obat">Product</a>
            <a href="#review">Review</a>           
        </nav>

        <div class="icons">
            <i class="fas fa-bars" id="menu-bars"></i>
            <i class="fas fa-search" id="search-icon"></i>
            <a href="#" class="fas fa-heart"></a>
            <a href="#" class="fas fa-shopping-cart"></a>
        </div>

    </header>
<!-- END HEADER -->

<!-- UNTUK MEMBUAT TAMPILAN SEARCH -->
<form action="" id="search-form">
    <input type="search" placeholder="carii disniii" name="" id="sercing">
    <label for="sercing" class="fas fa-search"></label>
    <i class="fas fa-times" id="close"></i>
</form>
<!-- END SEARCH -->

    <div class="container">
        <div class="product-details">
            <div class="product-image">
                <img src="../ICONS/Obat Miconazole.png" alt="Gambar Produk">
            </div>
            <div class="product-info">
                <h1>Miconazole 2% Cream 10 g</h1>
                <span>Rp.8.000/tube</span>
                <a href="../index1.php?#obat" class="btn">Pembelian</a>
                <div class="product-details-section">
                    <h2>Deskripsi</h2>
                    <p>MICONAZOLE CREAM merupakan obat antijamur golongan imidazol yang mengandung miconazole.
                    Krim ini digunakan secara topikal atau pada membran mukosa untuk mengobati infeksi yang 
                    disebabkan oleh fungi Trichophyton, Epidermophyton, Microsporum, Candida, dan Malessezia furfur. 
                    Miconazol bekerja menghambat biosintesis ergosterol pada jamur dan mengubah komposisi komponen
                    lipid lain di dalam membran, sehingga mengakibatkan nekrosis sel jamur.
                    </p>
                    <h2>Indikasi Umum</h2>
                    <p>
                    Krim ini digunakan secara topikal atau pada membran mukosa untuk mengatasi infeksi yang
                    disebabkan oleh fungi, atau digunakan pada terapi Tinea Pedis (kaki atlet), Tinea Kruris
                    & Tinea Korporis yang disebabkan oleh Trikhofiton Rubrum, Trikhofiton Mentagrofits & 
                    Epidermofiton Flokosum, kandidiasis Kutaneus (Moniliasis) & Tinea Versikolor.
                    </p>
                    <h2>komposisi</h2>
                    <p>Miconazole nitrate 2%</p>
                    <h2>Dosis</h2>
                    <p>Oleskan 2 kali per hari selama 2 sampai 4 minggu.</p>
                    <h2>Aturan Pakai :</h2>
                    <p>Dioleskan dengan keadaan bersih pada area kulit yang sakit atau terinfeksi.</p>
                    <h2>Perhatian</h2>
                    <p>Hanya untuk bagian luar badan. Hindari kontak langsung dengan mata. Hentikan penggunaan
                    jika terjadi iritasi. Hamil dan laktasi. Kategori Kehamilan : Kategori C: Mungkin berisiko. 
                    Obat digunakan dengan hati-hati apabila besarnya manfaat yang diperoleh melebihi besarnya 
                    risiko terhadap janin. Penelitian pada hewan uji menunjukkan risiko terhadap janin dan belum 
                    terdapat penelitian langsung terhadap wanita hamil.</p>
                    <h2>Kontra Indikasi</h2>
                    <p>Hipersensitivitas</p>
                    <h2>Efek Samping</h2>
                    <p>Pemakaian obat umumnya memiliki efek samping tertentu dan sesuai dengan masing-masing individu. 
                    Jika terjadi efek samping yang berlebih dan berbahaya, harap konsultasikan kepada tenaga medis. Efek
                     samping yang mungkin terjadi dalam penggunaan obat adalah: Sensasi rasa terbakar, dermatitis kontak</p>
                    <h2>Golongan Produk</h2>
                    <p>Obat Bebas Terbatas (Biru)</p>
                    <h2>Kemasan</h2>
                    <p>Tube @ 10 g</p>
                    <h2>Manufaktur</h2>
                    <p>Generic Manufacturer</p>
                    <h2>No. Registrasi</h2>
                    <p>BPOM: GTL9832301029A1</p>
                </div>
                
            </div>
        </div>
    </div>
</body>
</html>

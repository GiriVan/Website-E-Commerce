<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Apotek Kami</title>

    <!-- FONT AWESOME CDN LINK -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">

    <!-- SWIPER UNTUK BISA NGE SLIDER-->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css">

    <!-- HUBUNGKAN KE CSS -->
    <link rel="stylesheet" href="css/style2.css">

    <style>
   

    </style>

</head>
<body>

    <!-- header -->
    <header>
        
        <a href="#" class="logo"><i class="fa fa-hospital"></i>Apotek.</a>

        <nav class="navbar">
            <a class="" href="#home">Home</a>
            <a href="#about">About</a>
            <a href="#obat">Product</a>
            <a href="#review">Review</a>           
        </nav>

        <div class="icons">
            <i class="fas fa-bars" id="menu-bars"></i>
            <i class="fas fa-search" id="search-icon"></i>
            <a href="#" class="fas fa-heart"></a>
            <a href="#" class="fas fa-shopping-cart"></a>
        </div>

    </header>
<!-- END HEADER -->

<!-- UNTUK MEMBUAT TAMPILAN SEARCH -->
<form action="" id="search-form">
    <input type="search" placeholder="carii disniii" name="" id="sercing">
    <label for="sercing" class="fas fa-search"></label>
    <i class="fas fa-times" id="close"></i>
</form>
<!-- END SEARCH -->

    <div class="container">
        <div class="product-details">
            <div class="product-image">
                <img src="../ICONS/Obat loperamide.png" alt="Gambar Produk">
            </div>
            <div class="product-info">
                <h1>Loperamide 2 mg 10 Tablet</h1>
                <span>Rp.3.500/strip</span>
                <a href="../index1.php?#obat" class="btn">Pembelian</a>
                <div class="product-details-section">
                    <h2>Deskripsi</h2>
                    <p>
                    LOPERAMIDE 2 MG TABLET adalah obat yang digunakan untuk mengatasi diare. Obat ini bekerja dengan cara memperlambat gerakan saluran pencernaan, sehingga usus punya lebih banyak waktu untuk menyerap cairan dan nutrisi dari makanan yang dikonsumsi. Dalam menggunakan obat ini HARUS SESUAI DENGAN PETUNJUK DOKTER. Pembelian obat ini memerlukan edukasi terkait penggunaan atau pengonsumsian obat yang tepat dan aman yang akan dikenakan biaya.
                    </p>
                    <h2>Indikasi Umum</h2>
                    <p>
                    INFORMASI OBAT INI HANYA UNTUK KALANGAN MEDIS. Diare akut non spesifik & diare kronik
                    </p>
                    <h2>komposisi</h2>
                    <p>Loperamide HCl 2 mg</p>
                    <h2>Dosis</h2>
                    <p>PENGGUNAAN OBAT INI HARUS SESUAI DENGAN PETUNJUK DOKTER. Dewasa : awal 2 tablet kemudian 1 tablet setiap habis defekasi. Maksimal : 8 tablet/hari. Anak >8 tahun : Awal : 1 tablet kemudian sesuai kebutuhan. Maksimal : 4-6 tablet/hari.</p>
                    <h2>Aturan Pakai :</h2>
                    <p>Sebelum atau sesudah makan</p>
                    <h2>Perhatian</h2>
                    <p style="font-weight: bold;">HARUS DENGAN RESEP DOKTER.</p> <p>Gagal ginjal dan hati, tidak dianjurkan untuk diare akut akibat infeksi E Coli, Salmonella dan Shingella, diare disertai demam tinggi atau feses berdarah. Tidak dianjurkan untuk penggunaan jangka panjang. Hamil, laktasi, dan anak. Kategori kehamilan: C</p>
                    <h2>Kontra Indikasi</h2>
                    <p>Kondisi dimana peristaltik tidak boleh dihambat. Anak di bawah 4 tahun.</p>
                    <h2>Efek Samping</h2>
                    <p>Sembelit, kram perut, pusing, kantuk, mual, muntah, dan mulut kering.</p>
                    <h2>Golongan Produk</h2>
                    <p>Obat Keras (Merah)</p>
                    <h2>Kemasan</h2>
                    <p>Dus, 10 Strip @ 10 Tablet</p>
                    <h2>Manufaktur</h2>
                    <p>Generic Manufacturer</p>
                    <h2>No. Registrasi</h2>
                    <p>BPOM: GKL0507116517A1</p>
                </div>
                
            </div>
        </div>
    </div>
</body>
</html>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Apotek Kami</title>

    <!-- FONT AWESOME CDN LINK -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">

    <!-- SWIPER UNTUK BISA NGE SLIDER-->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css">

    <!-- HUBUNGKAN KE CSS -->
    <link rel="stylesheet" href="css/style2.css">

    <style>
   

    </style>

</head>
<body>

    <!-- header -->
    <header>
        
        <a href="#" class="logo"><i class="fa fa-hospital"></i>Apotek.</a>

        <nav class="navbar">
            <a class="" href="#home">Home</a>
            <a href="#about">About</a>
            <a href="#obat">Product</a>
            <a href="#review">Review</a>           
        </nav>

        <div class="icons">
            <i class="fas fa-bars" id="menu-bars"></i>
            <i class="fas fa-search" id="search-icon"></i>
            <a href="#" class="fas fa-heart"></a>
            <a href="#" class="fas fa-shopping-cart"></a>
        </div>

    </header>
<!-- END HEADER -->

<!-- UNTUK MEMBUAT TAMPILAN SEARCH -->
<form action="" id="search-form">
    <input type="search" placeholder="carii disniii" name="" id="sercing">
    <label for="sercing" class="fas fa-search"></label>
    <i class="fas fa-times" id="close"></i>
</form>
<!-- END SEARCH -->

    <div class="container">
        <div class="product-details">
            <div class="product-image">
                <img src="../ICONS/Obat enzyplex.png" alt="Gambar Produk">
            </div>
            <div class="product-info">
                <h1>New Enzyplex 4 Tablet</h1>
                <span>Rp.13.000/strip</span>
                <a href="../index1.php?#obat" class="btn">Pembelian</a>
                <div class="product-details-section">
                    <h2>Deskripsi</h2>
                    <p>New Enzyplex merupakan obat yang mengandung amylase, protease, deoxycholid acid, dimethylpolisiloxane, vitamin B1, vitamin B2, vitamin B6, niacinamide, dan calcium panthothenate. Obat ini digunakan untuk membantu proses pencernaan dan mengatasi gangguan rasa kembung dan rasa penuh pada lambung akibat gangguan pencernaan. Amylase dan protease termasuk enzim pencernaan. Enzim ini bekerja dengan mempercepat pemecahan (hidrolisis) dari molekul makanan menjadi komponen-komponennya (seperti sukrosa yang terpecah menjadi glukosa dan fruktosa). Enzim ini membantu perncernaan dan menurunkan spasme lambung.</p>
                    <h2>Indikasi Umum</h2>
                    <p>Membantu proses pencernaan bermanfaat mencegah dan mengatasi gangguan pada pencernaan seperti rasa kembung, rasa penuh, pada lambung dan keadaan-keadaan di mana di butuhkan peningkatan enzim pencernaan seperti makan terlalu banyak, intoleransi terhadap makanan salah cerna dan lain-lain gangguan pencernaan fungsional.</p>
                    <h2>komposisi</h2>
                    <p>Amylase, protease, deoxycholid acid, dimethylpolisiloxane, vitamin B1, vitamin B2, vitamin B6, niacinamide, calcium panthothenate</p>
                    <h2>Dosis</h2>
                    <p>1-2 tablet per hari</p>
                    <h2>Aturan Pakai :</h2>
                    <p>Pada waktu makan, sesudah makan atau sesuai anjuran petunjuk dokter</p>
                    <h2>Perhatian</h2>
                    <p>Enzim pankreas dapat menyebabkan fibrosing colonopathy jika diberikan dalam dosis tinggi kepada pasien dengan fibrosis kistik. Tidak jelas apakah komplikasi ini disebabkan oleh dosis tinggi enzim pankreas atau karena penyakit yang mendasari. penggunaan calcium panthothenate harus dengan hati-hati pada orang yang menggunakan antikoagulan atau obat lain yang mampu memperpanjang waktu pendarahan.</p>
                    <h2>Kontra Indikasi</h2>
                    <p>Hipersensitifitas terhadap salah satu komponen obat. Kontraindikasi untuk pasien yang sedang mengalami pankreatitis akut atau eksaserbasi pankreatitis kronis akut. Kontraindikasi untuk pasien yang menggunakan antikoagulan.</p>
                    <h2>Efek Samping</h2>
                    <p>Pemakaian obat umumnya memiliki efek samping tertentu dan sesuai dengan masing-masing individu. Jika terjadi efek samping yang berlebih dan berbahaya, harap konsultasikan kepada tenaga medis. Efek samping yang mungkin terjadi dalam penggunaan obat adalah: Rasa tdk nyaman pada perut, konstipasi, dan dermatitis. BAB tidak normal, diare, heartburn (sensasi panas pada dada), mual, dan muntah.</p>
                    <h2>Golongan Produk</h2>
                    <p>Obat Bebas (Hijau)</p>
                    <h2>Kemasan</h2>
                    <p>Dus, 25 strip @ 4 tablet</p>
                    <h2>Manufaktur</h2>
                    <p>Medifarma</p>
                    <h2>No. Registrasi</h2>
                    <p>BPOM: DBL2014711616A1</p>
                </div>
                
            </div>
        </div>
    </div>
</body>
</html>

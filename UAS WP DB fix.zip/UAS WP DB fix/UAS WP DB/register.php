<?php
require 'backend_apotek/konekDB.php';
session_start();

// Buat session nope, alamat, dan email
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submit'])) {
    // Proses data formulir dan atur variabel sesi
    $_SESSION['nope'] = $_POST['nope'];
    $_SESSION['alamat'] = $_POST['alamat'];
}

if (isset($_POST["submit"])) {

    $nama_lengkap = $_POST["name"];
    $username = $_POST["username"];
    $email = $_POST["email"];
    $nope = $_POST["nope"];
    $alamat = $_POST["alamat"];
    $password = $_POST["password"];
    $confirmPassword = $_POST["confirm-password"];

    // Jadikan username yang sudah ada di database tidak boleh sama 
    $konek = mysqli_query($conn, "SELECT username FROM login WHERE username = '$username'");
    if (mysqli_fetch_assoc($konek)) {
        echo "<script> 
                alert('Username sudah digunakan');
                window.location='register.php';
              </script>";
        return false;
    }

    // Password harus sama dengan konfirmasi password
    if ($password !== $confirmPassword) {
        echo "<script> 
                alert ('Password tidak sama');
                window.location='register.php';
              </script>";
        return false;
    }

    $password2 = $password;

    $sambung = "INSERT INTO login (id, nama_lengkap, username, nope, email, alamat, password) VALUES ('', '$nama_lengkap', '$username', '$nope', '$email', '$alamat', '$password2')";
    $hubung = mysqli_query($conn, $sambung);

    if ($hubung) {
        echo "<script>
                alert('Registrasi berhasil');
                window.location='login.php';
              </script>";
    } else {
        echo "<script>
                alert('Registrasi gagal');
                window.location='register.php';
              </script>";
    }
}
?>

<!DOCTYPE html>
<html>

<head>
    <title>Registrasi</title>
    <style>
        /* Gaya CSS untuk tata letak dan tampilan form */
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-size: contain;
            background-repeat: no-repeat;
            background-position: center;
            background: rgb(208, 239, 219);
            background: radial-gradient(circle, rgba(208, 239, 219, 1) 16%, rgba(80, 220, 228, 1) 79%);
            background-size: 100% auto;
        }

        .container {
            max-width: 400px;
            margin: 100px auto;
            padding: 20px;
            text-align: center;
            border-radius: 30px;
            background-color: rgba(255, 255, 255, 0.8);
            color: black;
        }

        h2 {
            text-align: center;
            color: black;
        }

        .form-group {
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            margin-left: 80px;
            color: black;
        }

        .form-group label {
            display: block;
        }

        .form-group input[type="text"],
        .form-group input[type="email"],
        .form-group input[type="number"],
        .form-group input[type="password"] {
            width: 70%;
            padding: 10px;
            border-radius: 10px;
            text-align: center;
        }

        .form-button {
            text-align: center;
        }

        .form-button button {
            padding: 10px 20px;
            background-color: black;
            color: #fff;
            border: none;
            cursor: pointer;
            text-decoration: none;
        }

        .form-button button:hover {
            background-color: grey;
        }

        .login-text {
            text-align: center;
            margin-top: 20px;
            color: black;
        }

        .login-link {
            color: #4CAF50;
            text-decoration: none;
            font-weight: bold;
        }

        .login-link:hover {
            color: black;
        }
    </style>
</head>

<body background="bg1.jpg">
    <div class="container">
        <h2>REGISTRATION FORM</h2>
        <form method="POST" action="">
            <div class="form-group">
                <input type="text" id="name" name="name" placeholder="Nama Lengkap" required>
            </div>
            <div class="form-group">
                <input type="text" id="username" name="username" placeholder="Username" required>
            </div>
            <div class="form-group">
                <input type="email" id="email" name="email" placeholder="Email" required>
            </div>
            <div class="form-group">
                <input type="text" id="nope" name="nope" placeholder="No Handphone" required>
            </div>
            <div class="form-group">
                <input type="text" id="alamat" name="alamat" placeholder="Alamat" required>
            </div>
            <div class="form-group">
                <input type="password" id="password" name="password" placeholder="Password" required>
            </div>
            <div class="form-group">
                <input type="password" id="confirm-password" name="confirm-password" placeholder="Confirm Password" required>
            </div>

            <div class="form-button">
                <button type="submit" id="btn-register" name="submit">Register </button>
            </div>
        </form>
        <div class="login-text">
            Sudah punya akun? <a class="login-link" href="login.php">Login </a> sekarang
        </div>
    </div>
</body>

</html>

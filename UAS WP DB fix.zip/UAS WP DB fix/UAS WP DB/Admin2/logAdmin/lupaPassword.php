<?php
require '../DB/konekDB.php';

$sambung = query("SELECT * FROM tb_login");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link href="//netdna.bootstrapcdn.com/bootstrap/3.1.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
</head>
<body>
    <div class="container my-4">    
        <div id="loginbox" style="margin-top:50px;" class="mainbox col-md-6 col-md-offset-3 col-sm-8 col-sm-offset-2">                    
            <div class="panel panel-info" >
                <div class="panel-heading">
                    <div class="panel-title">Registrasi</div>
                </div>     
                 

                <?php foreach($sambung as $bung) : ?>
                    <form action="prosesLupa_password.php?id=<?= $bung["id"]; ?>" method="POST">
                        <ul>
                            <li>
                                <label>name</label>
                                <input type="text" id="" name="username" autocomplete="off">
                            </li>

                            <li>
                                <label>password</label>
                                <input type="password" id="" name="password" autocomplete="off">
                            </li>

                            <li>
                                <label>konfirmasi password</label>
                                <input type="password" id="" name="konfirmasiPassword" autocomplete="off">
                            </li>

                            <li>
                                <button type="submit">Registrasi</button>
                                <a href="login.php">Login</a>
                            </li>
                        </ul>
                    </form>
                <?php endforeach; ?>

            </div>                     
        </div>  
    </div>
</body>
</html>

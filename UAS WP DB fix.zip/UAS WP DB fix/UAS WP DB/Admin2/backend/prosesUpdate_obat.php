<?php
require '../DB/konekDB.php';

$id = $_GET['id'];
$nama_obat = mysqli_real_escape_string($conn, $_POST['nama_obat']); //mysqli_real_escape_string = sebuah array security biar tidak bisa nulis kodingan html di formnya
$penyimpanan = mysqli_real_escape_string($conn, $_POST['penyimpanan']);
$kategori = mysqli_real_escape_string($conn, $_POST['kategori']);
$stok = $_POST['stok'];
$kadaluwarsa = $_POST['kadaluwarsa'];
$harga = $_POST['harga'];
$unit = mysqli_real_escape_string($conn, $_POST['unit']);

$query = "UPDATE tb_obat SET 
           nama_obat='$nama_obat',
           penyimpanan='$penyimpanan',
           kategori='$kategori',
           stok='$stok',
           kadaluwarsa='$kadaluwarsa',
           harga='$harga',
           unit='$unit'
           WHERE id='$id'";
$eksekusi = mysqli_query($conn, $query);
if ($eksekusi){
    echo "<script> 
            alert('Data Berhasil di Update!');
            window.location.href='../obat.php';
            </script>";
        }
        else{
            echo "<script> 
            alert('Data Gagal di Update!');
            window.location.href='../update_obat.php';
           
    </script>";
}
?>
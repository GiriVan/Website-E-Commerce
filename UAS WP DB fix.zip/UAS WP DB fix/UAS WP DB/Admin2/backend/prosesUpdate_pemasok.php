<?php
require '../DB/konekDB.php';

$id = $_GET['id'];
$nama_pemasok = mysqli_real_escape_string($conn, $_POST['nama_pemasok']); //mysqli_real_escape_string = sebuah array security biar tidak bisa nulis kodingan html di formnya
$alamat = mysqli_real_escape_string($conn, $_POST['alamat']);
$no_telepon = $_POST['no_telepon'];


$query = "UPDATE tb_pemasok SET 
           nama_pemasok='$nama_pemasok',
           alamat='$alamat',
           no_telepon='$no_telepon'
           WHERE id='$id'";

$eksekusi = mysqli_query($conn, $query);
if ($eksekusi){
    echo "<script> 
            alert('Data Berhasil di Update!');
            window.location.href='../pemasok.php';
            </script>";
        }
        else{
            echo "<script> 
            alert('Data Gagal di Update!');
            window.location.href='../update_pemasok.php';
           
    </script>";
}
?>
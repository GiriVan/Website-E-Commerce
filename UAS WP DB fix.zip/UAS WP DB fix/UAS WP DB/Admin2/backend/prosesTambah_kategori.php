<?php
    require '../DB/konekDB.php';

    $nama_kategori = $_POST["nama_kategori"];
    $deskripsi = $_POST["deskripsi"];

    $query = "INSERT INTO tb_kategori (nama_kategori, deskripsi) 
              VALUES ('$nama_kategori', '$deskripsi')";

    $cek = mysqli_query($conn, $query);

    if ($cek) {
        echo "<script> alert('Kategori berhasil ditambahkan'); 
              document.location.href = '../kategori.php';
             </script>";
    } else {
        echo "<script> alert('Kategori gagal ditambahkan');
            document.location.href = '../tambah_kategori.php';
            </script>";
    }
?>

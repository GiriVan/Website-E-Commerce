<?php
    require '../DB/konekDB.php';

    $nama_pemasok = $_POST["nama_pemasok"];
    $alamat = $_POST["alamat"];
    $no_telepon = $_POST["no_telepon"];

    $query = "INSERT INTO tb_pemasok (nama_pemasok, alamat ,no_telepon) 
              VALUES ('$nama_pemasok', '$alamat', '$no_telepon')";

    $cek = mysqli_query($conn, $query);

    if ($cek) {
        echo "<script> alert('Pemasok berhasil ditambahkan'); 
              document.location.href = '../pemasok.php';
             </script>";
    } else {
        echo "<script> alert('Pemasok gagal ditambahkan');
            document.location.href = '../tambah_pemasok.php';
            </script>";
    }
?>

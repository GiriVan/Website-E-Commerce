<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="../style.css">
    <link rel="stylesheet" href="https://maxst.icons8.com/vue-static/landings/line-awesome/line-awesome/1.3.0/css/line-awesome.min.css">
    <style>
    /* CSS UNTUK HEADER */
header {
    position: fixed;
    right: 0;
    top: 0;
    left: 165px;
    z-index: 100;
    height: 60px;
    box-shadow: 0px 5px 5px -5px rgb(0 0 0 /10%);
    background: #34425A;
    transition: left 300ms;
}
/* PENUTUP */

/* SIDEBAR */
.sidebar {
    position: fixed;
    height: 100%;
    width: 165px;
    left: 0;
    bottom: 0;
    top: 0;
    z-index: 100;
    background: #34425A;
    transition: left 300ms;
}
/* PENUTUP */

/* FORM TAMBAH DATA OBAT */
form {
    max-width: 400px;
    margin: 0 auto;
}

label {
    display: block;
    margin-bottom: 8px;
}

input {
    width: 100%;
    padding: 8px;
    margin-bottom: 12px;
    box-sizing: border-box;
}

button {
    background-color: #3498db; /* Warna latar biru */
    color: #ffffff; /* Warna teks putih */
    padding: 10px 15px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
}

button:hover {
    background-color: #2980b9; /* Warna latar biru lebih gelap saat hover */
}

/* PENUTUP */
</style>
</head>
<body>
   <input type="checkbox" id="menu-toggle">
    <div class="sidebar">
        <div class="side-content">
            <div class="profile">
                <div class="profile-img bg-img" style="background-image: url(../img/cewe\ \(5\).png)"></div>
                <h4>MyApotek.</h4>
                <small>Tersedia macam obat</small>
            </div>

            <div class="side-menu">
                <ul>
                    <li>
                       <a href="../index.php" class="">
                            <span class="las la-home" style="color: white;"></span>
                            <small>Dashboard</small>
                        </a>
                    </li>
                    <!-- <li>
                       <a href="profile.php">
                            <span class="las la-user-alt"></span>
                            <small>Profile</small>
                        </a>
                    </li> -->
                    <li>
                        <a href="../kategori.php">
                            <span class="las la-clipboard-list" style="color: white;"></span>
                            <small>Kategori</small>
                        </a>
                    </li>
                    <li>
                       <a href="../obat.php">
                            <span class="las la-pills" style="color: white;"></span>
                            <small>Obat</small>
                        </a>
                    </li>
                    <li>
                        <a href="../pemasok.php">
                            <span class="las la-user-friends" style="color: white;"></span>
                            <small>Pemasok</small>
                        </a>
                    </li>
                    <li>
                        <a href="order.php">
                            <span class="las la-shopping-cart"  style="color: white;"></span>
                            <small>Orders</small>
                        </a>
                    </li>
                    <a href="logAdmin/logout.php" onclick="return confirm('Apakah anda yakin?');">
                    <span class="las la-power-off" style="color: white;"></span> 
                    <small>Logout</small>
                    </a>
                    </li>
                    <!-- <li>
                        <a href="product.php">
                            <span class="las la-tasks"></span>
                            <small>Produk</small>
                        </a>
                    </li> -->

                </ul>
            </div>
        </div>
    </div>
    
    <div class="main-content">
        
        <header>
            <div class="header-content">
                <label for="menu-toggle">
                    <span class="las la-bars" style="color: white;"></span>
                </label>
                
                <div class="header-menu">
                    <label for="">
                        <span class="las la-search" style="color: white;"></span>
                    </label>
                    
                    <div class="notify-icon">
                        <span class="las la-envelope" style="color: white;"></span>
                        <span class="notify">4</span>
                    </div>
                    
                    <div class="notify-icon">
                        <span class="las la-bell" style="color: white;"></span>
                        <span class="notify">3</span>
                    </div>
                    
                    <div class="user">
                        <div class="bg-img" style="background-image: url(../img/cewe\ \(5\).png)"></div>
                       
                    </div>
                </div>
            </div>
        </header>

        <main>

        <div class="page-header">
                <h1>MyApotek</h1>
                <small>Tambah Data Pemasok</small>
            </div>
            
            
            <div class="page-content">
            
    

                

                <form action="prosesTambah_pemasok.php" method="POST">

                        <label for="pemasok">Nama Pemasok</label>
                        <input type="text" name="nama_pemasok" id="pemasok" placeholder="nama pemasok" required><br>
                        <label for="alamat">Alamat</label>
                        <input type="text" name="alamat" id="alamat" placeholder="alamat" required><br>
                        <label for="no_telepon">No telepon</label>       
                        <input type="tel" name="no_telepon" id="no_telepon" placeholder="no telepon" required><br>

                        
                        <button>Tambah Pemasok</button>
                    </form>
                    <a href="../pemasok.php"><button>Batal</button></a>

                    

                
            
            </div>
            
        </main>
        
    </div>
    


    </form>
</body>
</html>
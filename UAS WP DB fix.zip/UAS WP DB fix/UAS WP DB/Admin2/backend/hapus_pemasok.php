<?php
    require '../DB/konekDB.php';

    $id = $_GET["id"];

    $hapus = "DELETE FROM tb_pemasok WHERE id = '$id'";
    $delet = mysqli_query($conn, $hapus);

    if ($delet) {
        echo "<script> alert('Data berhasil dihapus'); 
              document.location.href = '../pemasok.php';
             </script>";
    } else {
        echo "<script> alert('Data gagal dihapus');
            document.location.href = '../pemasok.php';
            </script>";
    }
?>

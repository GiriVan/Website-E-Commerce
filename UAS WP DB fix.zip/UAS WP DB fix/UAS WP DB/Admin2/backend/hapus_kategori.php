<?php
    require '../DB/konekDB.php';

    $id = $_GET["id"];

    $hapus = "DELETE FROM tb_kategori WHERE id = '$id'";
    $delet = mysqli_query($conn, $hapus);

    if ($delet) {
        echo "<script> alert('Data berhasil dihapus'); 
              document.location.href = '../kategori.php';
             </script>";
    } else {
        echo "<script> alert('Data gagal dihapus');
            document.location.href = '../kategori.php';
            </script>";
    }
?>

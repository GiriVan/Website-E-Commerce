<?php
session_start();
require 'DB/konekDB.php';

if (!isset($_SESSION['session_username']) && $_COOKIE['cookie_username'] && $_COOKIE['cookie_password']) {
    $cookie_username = $_COOKIE['cookie_username'];
    $cookie_password = $_COOKIE['cookie_password'];

    $sql1 = "SELECT * FROM tb_login WHERE username = '$cookie_username'";
    $giri1 = mysqli_query($conn, $sql1);
    $van1 = mysqli_fetch_array($giri1);

    if ($van1 && isset($van1['password']) && $van1['password'] == $cookie_password) {
        $_SESSION['session_username'] = $cookie_username;
        $_SESSION['session_password'] = $cookie_password;
    }
}

if (!isset($_SESSION['session_username'])) {
    header("location: logAdmin/login.php");
    exit();
}


$query1 = $conn->query("SELECT * FROM tb_obat");
$query2 = $conn->query("SELECT * FROM tb_pemasok");
$query3 = $conn->query("SELECT * FROM tb_kategori");


$jml_obat = mysqli_num_rows($query1);
$jml_pemasok = mysqli_num_rows($query2);
$jml_kategori = mysqli_num_rows($query3);

?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1">
    <title>Admin MyApotek</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://maxst.icons8.com/vue-static/landings/line-awesome/line-awesome/1.3.0/css/line-awesome.min.css">
<style>
/* SIDEBAR */
.sidebar {
    position: fixed;
    height: 100%;
    width: 165px;
    left: 0;
    bottom: 0;
    top: 0;
    z-index: 100;
    background: #34425A;
    transition: left 300ms;
}
/* PENUTUP */
/* CSS UNTUK DI BAGIAN CARD */
.card {
    box-shadow: 0px 5px 5px -5px rgb(0 0 0 / 10%);
    background: rgb(208,239,219);
    background: radial-gradient(circle, rgba(208,239,219,1) 16%, rgba(80,220,228,1) 79%);
    padding: 1rem;
    border-radius: 3px;
}

.card-progress small{
    color:black;
    font-weight: bold;
}
/* PENUTUP */
/* CSS UNTUK HEADER */
header {
    position: fixed;
    right: 0;
    top: 0;
    left: 165px;
    z-index: 100;
    height: 60px;
    box-shadow: 0px 5px 5px -5px rgb(0 0 0 /10%);
    background: #34425A;
    transition: left 300ms;
}
/* PENUTUP */
</style>
</head>
<body>
   <input type="checkbox" id="menu-toggle">
    <div class="sidebar">
        
        <div class="side-content">
            <div class="profile">
                <div class="profile-img bg-img" style="background-image: url(img/cewe\ \(5\).png)"></div>
                <h4>MyApotek</h4>
                <small>Tersedia macam obat</small>
            </div>

            <div class="side-menu">
                <ul>
                    <li>
                       <a href="index.php" class="">
                            <span class="las la-home"  style="color: white;"></span>
                            <small>Dashboard</small>
                        </a>
                    </li>
                    <!-- <li>
                       <a href="profile.php">
                            <span class="las la-user-alt"></span>
                            <small>Profile</small>
                        </a>
                    </li> -->
                    <li>
                        <a href="kategori.php">
                            <span class="las la-clipboard-list"  style="color: white;"></span>
                            <small>Kategori</small>
                        </a>
                    </li>
                    <li>
                       <a href="obat.php">
                            <span class="las la-pills"  style="color: white;"></span>
                            <small>Obat</small>
                        </a>
                    </li>
                    <li>
                        <a href="pemasok.php">
                            <span class="las la-user-friends"  style="color: white;"></span>
                            <small>Pemasok</small>
                        </a>
                    </li>
                    <li>
                        <a href="order.php">
                            <span class="las la-shopping-cart"  style="color: white;"></span>
                            <small>Orders</small>
                        </a>
                    </li>
                    <a href="logAdmin/logout.php" onclick="return confirm('Apakah anda yakin?');">
                    <span class="las la-power-off" style="color: white;"></span> 
                    <small>Logout</small>
                    </a>
                    </li>
                    <!-- <li>
                        <a href="product.php">
                            <span class="las la-tasks"></span>
                            <small>Produk</small>
                        </a>
                    </li> -->

                </ul>
            </div>
        </div>
    </div>
    
    <div class="main-content">
        
        <header>
            <div class="header-content">
                <label for="menu-toggle">
                    <span class="las la-bars" style="color: white;"></span>
                </label>
                
                <div class="header-menu">
                    <label for="">
                        <span class="las la-search" style="color: white;"></span>
                    </label>
                    
                    <div class="notify-icon">
                        <span class="las la-envelope" style="color: white;"></span>
                        <span class="notify">4</span>
                    </div>
                    
                    <div class="notify-icon">
                        <span class="las la-bell" style="color: white;"></span>
                        <span class="notify">3</span>
                    </div>
                    
                    <div class="user">
                        <div class="bg-img" style="background-image: url(img/cewe\ \(5\).png)"></div>
                    </div>
                </div>
            </div>
        </header>
        
        
        <main>
            
            <div class="page-header">
                <h1>Dashboard</h1>
                <small>Home / Dashboard</small>
            </div>
            
            <div class="page-content">
            
                <div class="analytics">

                    <div class="card">
                        <div class="card-head">
                            <?= number_format($jml_obat,0,",","."); ?>
                            <span class="las la-pills" style="color: black;"></span>
                        </div>
                        <div class="card-progress">
                            <small>Total Obat</small>
                            <div class="card-indicator" >
                                <div class="indicator one" style="width: 60%"></div>
                            </div>
                        </div>
                    </div>

                    <div class="card">
                        <div class="card-head">
                        <?= number_format($jml_pemasok,0,",","."); ?>
                            <span class="las la-user-friends" style="color: black;"></span>
                        </div>
                        <div class="card-progress">
                            <small>Total Pemasok</small>
                            <div class="card-indicator">
                                <div class="indicator two" style="width: 80%"></div>
                            </div>
                        </div>
                    </div>

                    <div class="card">
                        <div class="card-head">
                        <?= number_format($jml_kategori,0,",","."); ?>
                            <span class="las la-clipboard-list" style="color: black;"></span>
                        </div>
                        <div class="card-progress">
                            <small>Total Kategori</small>
                            <div class="card-indicator">
                                <div class="indicator three" style="width: 65%"></div>
                            </div>
                        </div>
                    </div>

                    <!-- KARENA DATABASENYA BERBEDA JADI BUAT LAGI MYSQL NYA -->
                    <?php 
                        $conn = mysqli_connect("localhost", "root", "", "productdb");
                        $query4 = $conn->query("SELECT * FROM checkout");
                        $jml_orders = mysqli_num_rows($query4);
                    ?>
                        <div class="card">  
                            <div class="card-head">
                            <?= number_format($jml_orders,0,",","."); ?>
                                <span class="las la-shopping-cart" style="color: black;"></span>
                            </div>
                            <div class="card-progress">
                                <small>Total Orders</small>
                                <div class="card-indicator">
                                    <div class="indicator four" style="width: 90%"></div>
                                </div>
                            </div>
                        </div>

                </div>


                
            
            </div>
            
        </main>
        
    </div>
</body>
</html>
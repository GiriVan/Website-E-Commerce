document.addEventListener('DOMContentLoaded', function () {
    var confirmationButtons = document.querySelectorAll('.confirmationButton');

    confirmationButtons.forEach(function (button) {
        // Mengecek status terakhir dari localStorage saat halaman dimuat
        var isConfirmed = localStorage.getItem('confirmationStatus') === 'true';

        // Menetapkan status awal dari localStorage
        button.classList.toggle('clicked', isConfirmed);
        toggleButtonText(button);

        button.addEventListener('click', function () {
            if (!button.classList.contains('clicked')) {
                button.classList.add('clicked');
                toggleButtonText(button);
                showStatusAlert(button);
                disableButtonsAfterConfirmation();

                // Menyimpan status ke localStorage
                localStorage.setItem('confirmationStatus', 'true');
            }
        });
    });

    function toggleButtonText(button) {
        if (button.classList.contains('clicked')) {
            button.innerText = 'Pesanan Terkirim';
        } else {
            button.innerText = 'Konfirmasi Pembayaran';
        }
    }

    function showStatusAlert(button) {
        var status = button.classList.contains('clicked') ? 'Terkirim' : 'Konfirmasi Pembayaran';
        alert('Status order berhasil diupdate');
    }

    function disableButtonsAfterConfirmation() {
        confirmationButtons.forEach(function (button) {
            button.removeEventListener('click', handleClick);
        });
    }
});

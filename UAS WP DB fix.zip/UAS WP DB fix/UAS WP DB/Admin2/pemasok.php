<?php
    require 'DB/konekDB.php';

    $sambung = query("SELECT * FROM tb_pemasok");

    if (isset($_POST["cari"]) ) {
        $ketik = $_POST["ketik"];
        $sambung = query("SELECT * FROM tb_pemasok WHERE
                 nama_pemasok LIKE '%$ketik%' OR   
                 Alamat LIKE '$ketik' OR
                 no_telepon LIKE '$ketik'
                ");
    }

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://maxst.icons8.com/vue-static/landings/line-awesome/line-awesome/1.3.0/css/line-awesome.min.css">
    <style>
/* CSS UNTUK HEADER */
header {
    position: fixed;
    right: 0;
    top: 0;
    left: 165px;
    z-index: 100;
    height: 60px;
    box-shadow: 0px 5px 5px -5px rgb(0 0 0 /10%);
    background: #34425A;
    transition: left 300ms;
}
/* PENUTUP */

/* SIDEBAR */
.sidebar {
    position: fixed;
    height: 100%;
    width: 165px;
    left: 0;
    bottom: 0;
    top: 0;
    z-index: 100;
    background: #34425A;
    transition: left 300ms;
}
/* PENUTUP */

/* CSS UNTUK TABEL*/
table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 20px;
    
}

/* Gaya untuk Header Tabel */
thead {
    background-color: #f2f2f2;
}

th, td {
    padding: 12px;
    text-align: left;
    border-bottom: 1px solid #ddd;
   
}

/* Gaya untuk Tombol Aksi */
button {
    padding: 8px 12px;
    margin-right: 5px;
    cursor: pointer;
}

/* Gaya untuk Tanda Panah Urutan */
.la-sort {
    margin-left: 5px;
    font-size: 12px;
}

/* PENUTUP */

/* CSS UNTUK BUTTON HAPUS DAN EDIT  */
.edit-button,
.la-trash {
    display: inline-block;
    padding: 8px 12px;
    text-decoration: none;
    border-radius: 4px;
    cursor: pointer;
}

.la-edit {
    background-color: #1E90FF; /* Biru */
    color: #ffffff; /* Putih */
    border-radius: 4px;
}

.la-trash {
    background-color: #e74c3c; /* Merah */
    color: #ffffff; /* Putih */
}

.la-edit:hover,
.la-trash:hover {
    opacity: 0.8;
    
}

/* PENUTUP */

/* CSS TOMBOL TAMBAH PEMASOK */
.add-supplier-button {
    cursor: pointer;
    padding: 8px 12px;
    background-color: #e67e22; /* Warna latar jingga */
    color: #ffffff; /* Warna teks putih */
    border: none;
    border-radius: 4px;
    transition: background-color 0.3s ease; /* Efek transisi saat hover */
}

.add-supplier-button:hover {
    background-color: #2980b9; /* Warna latar biru lebih gelap saat hover */
}
/* PENUTUP */
</style>
</head>
<body>
   <input type="checkbox" id="menu-toggle">
    <div class="sidebar">
        <div class="side-content">
            <div class="profile">
                <div class="profile-img bg-img" style="background-image: url(img/cewe\ \(5\).png)"></div>
                <h4>MyApotek.</h4>
                <small>Tersedia macam obat</small>
            </div>

            <div class="side-menu">
                <ul>
                    <li>
                       <a href="index.php" class="">
                            <span class="las la-home" style="color: white;"></span>
                            <small>Dashboard</small>
                        </a>
                    </li>
                    <!-- <li>
                       <a href="profile.php">
                            <span class="las la-user-alt"></span>
                            <small>Profile</small>
                        </a>
                    </li> -->
                    <li>
                        <a href="kategori.php">
                            <span class="las la-clipboard-list" style="color: white;"></span>
                            <small>Kategori</small>
                        </a>
                    </li>
                    <li>
                       <a href="obat.php">
                            <span class="las la-pills" style="color: white;"></span>
                            <small>Obat</small>
                        </a>
                    </li>
                    <li>
                        <a href="pemasok.php">
                            <span class="las la-user-friends" style="color: white;"></span>
                            <small>Pemasok</small>
                        </a>
                    </li>
                    <li>
                        <a href="order.php">
                            <span class="las la-shopping-cart"  style="color: white;"></span>
                            <small>Orders</small>
                        </a>
                    </li>
                    <a href="logAdmin/logout.php" onclick="return confirm('Apakah anda yakin?');">
                    <span class="las la-power-off" style="color: white;"></span> 
                    <small>Logout</small>
                    </a>
                    </li>
                    <!-- <li>
                        <a href="product.php">
                            <span class="las la-tasks"></span>
                            <small>Produk</small>
                        </a>
                    </li> -->

                </ul>
            </div>
        </div>
    </div>
    
    <div class="main-content">
        
        <header>
            <div class="header-content">
                <label for="menu-toggle">
                    <span class="las la-bars" style="color: white;"></span>
                </label>
                
                <div class="header-menu">
                    <label for="">
                        <span class="las la-search" style="color: white;"></span>
                    </label>
                    
                    <div class="notify-icon">
                        <span class="las la-envelope" style="color: white;"></span>
                        <span class="notify">4</span>
                    </div>
                    
                    <div class="notify-icon">
                        <span class="las la-bell" style="color: white;"></span>
                        <span class="notify">3</span>
                    </div>
                    
                    <div class="user">
                        <div class="bg-img" style="background-image: url(img/cewe\ \(5\).png)"></div>
                    </div>
                </div>
            </div>
        </header>
        
        
        <main>

        <div class="page-header">
                <h1>MyApotek</h1>
                <small>Data Pemasok</small>
            </div>
            
            
            <div class="page-content">
            
    

                <div class="records table-responsive">

                    <div class="record-header">
                        <div class="add">
                        <button onclick="window.location.href='backend/tambah_pemasok.php'" class="add-supplier-button">Tambah Pemasok</button>

                        </div>

                        <div class="browse">
                            <form action="" method="POST">
                                <button name="cari">Cari</button>
                           <input type="search" name="ketik" placeholder="Pencarian" class="record-search" autocomplete="off">
                            <!-- <select name="" id="">
                                <option value="">Status</option>
                            </select> -->
                            </form>
                        </div>
                    </div>

                    <div>
                        <table width="100%">
                            <thead >
                                <tr>
                                    <th>No.</th>                
                                    <th><span class="las la-sort"></span> Nama Pemasok</th>
                                    <th><span class="las la-sort"></span> Alamat</th>
                                    <th><span class="las la-sort"></span> No.telepon</th>
                                    <th><span class="las la-sort"></span> Aksi</th>
                                </tr>

                                <?php $i = 1 ?>
                                <?php foreach($sambung as $bung) : ?>
                                <tr>
                                    <td><?= $i ?></td>
                                    <td><?= $bung["nama_pemasok"]?></td>
                                    <td><?= $bung["alamat"]?></td>
                                    <td><?= $bung["no_telepon"]?></td>
                                    <td>
                                    <button onclick="window.location.href='backend/update_pemasok.php?id=<?= $bung['id']; ?>'" class="button-link las la-edit">Edit</button>
                                    <button onclick="if(confirm('Yakin?')){window.location.href='backend/hapus_pemasok.php?id=<?= $bung['id']; ?>'}" class="button-link las la-trash">Hapus</button>
                                    </td>
                                    
                
                                    <?php $i++ ?>
                                    <?php endforeach ?>
                                    </tr>

                            </thead>
                            
                        </table>
                    </div>

                </div>
            
            </div>
            
        </main>
        
    </div>
</body>
</html>
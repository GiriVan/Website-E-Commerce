<?php
session_start();
require 'konekDB.php';

// Mengambil data dari form
$namaLengkap = $_POST["name"];
$nomorHandphone = $_POST["nomor_handphone"];
$alamat = $_POST["alamat"];
$pmode = $_POST["pmode"];
$pmode1 = $_POST["pmode1"];
$total_pesanan = $_SESSION["total"];

// Mengambil deskripsi produk dari tabel semua_produk
$queryDeskripsi = "SELECT GROUP_CONCAT(description SEPARATOR ', ') AS deskripsi_produk FROM semua_produk";
// fungsi GROUP_CONCAT pada SQL untuk menggabungkan semua deskripsi produk menjadi satu string(separator) yang dipisahkan oleh koma. 
// Kemudian disimpan ke dalam kolom deskripsi_produk pada tabel checkout.
$resultDeskripsi = mysqli_query($conn, $queryDeskripsi);

// Mengambil hasil query
if ($resultDeskripsi) {
    $rowDeskripsi = mysqli_fetch_assoc($resultDeskripsi);
    $deskripsi_produk = $rowDeskripsi['deskripsi_produk'];

    // Simpan data ke dalam database
    $query = "INSERT INTO checkout (nama_lengkap, nomor_handphone, alamat, metode_pembayaran, metode_pengiriman, total, deskripsi_produk)
              VALUES ('$namaLengkap', '$nomorHandphone', '$alamat', '$pmode', '$pmode1', '$total_pesanan', '$deskripsi_produk')";

    $konek = mysqli_query($conn, $query);
    
    if ($konek) {
        echo "<script>
                alert('Pesanan Anda berhasil diproses');
                window.location='../bayar.php';
            </script>";
        
    } else {
        echo "<script>
                alert('Pesanan Anda gagal diproses');
                window.location='../detailCO.php';
            </script>";
    }
} else {
    // Handle kesalahan jika query tidak berhasil
    echo "Error: " . mysqli_error($conn);
}


// session_start();
// require 'konekDB.php';

// // Mengambil data dari form
// $namaLengkap = $_POST["nama_lengkap"];
// $nomorHandphone = $_POST["nomor_handphone"];
// $alamat = $_POST["alamat"];
// $pmode = $_POST["pmode"];
// $pmode1 = $_POST["pmode1"];
// $total_pesanan = $_SESSION["total"];

// // Simpan data ke dalam database
// $query = "INSERT INTO checkout (nama_lengkap, nomor_handphone, alamat, metode_pembayaran, metode_pengiriman, total)
//           VALUES ('$namaLengkap', '$nomorHandphone', '$alamat', '$pmode', '$pmode1', '$total_pesanan')";

// $konek = mysqli_query($conn, $query);

// // Memberikan konfirmasi

// if ($konek) {
//     echo "<script>
//             alert('Pesanan Anda berhasil diproses');
//             window.location='../bayar.php';
//         </script>";
//     session_destroy();
// } else {
//     echo "<script>
//             alert('Pesanan Anda gagal diproses');
//             window.location='../detailCO.php';
//         </script>";
// }
?>

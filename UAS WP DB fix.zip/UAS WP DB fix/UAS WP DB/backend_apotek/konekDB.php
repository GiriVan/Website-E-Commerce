<?php

$conn = mysqli_connect("localhost", "root", "", "productdb");


function query($konek){
    global $conn; //UNTUK MENGAMBIL VARIABEL CONN DIATAS KARENA KL FUNCTION HRS BUAT DLU GLOBAL KL MAU NGAMBIL VARIABEL DIATAS
    $query = mysqli_query($conn, $konek);
    $rows = [];
    while ($row = mysqli_fetch_assoc($query)) {
        $rows[] = $row;
    }
    return $rows;
}